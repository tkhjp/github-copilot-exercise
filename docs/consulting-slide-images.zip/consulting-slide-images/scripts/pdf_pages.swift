// 見本PDFをページ画像（JPEG）に書き出す。poppler不要、macOS標準のPDFKitを使う。
// 使い方: swiftc -O pdf_pages.swift -o /tmp/pdf_pages && /tmp/pdf_pages <deck.pdf> <出力先pages/> [幅px=1600]
import PDFKit
import AppKit
let a = CommandLine.arguments
guard a.count >= 3, let doc = PDFDocument(url: URL(fileURLWithPath: a[1])) else { print("usage: pdf_pages <pdf> <outdir> [width]"); exit(1) }
let out = a[2], width = a.count > 3 ? Int(a[3])! : 1600
for i in 0..<doc.pageCount {
  let p = doc.page(at: i)!
  let r = p.bounds(for: .mediaBox)
  let w = width, h = Int((CGFloat(width) * r.height / r.width).rounded())
  let rep = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: w, pixelsHigh: h, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
  NSGraphicsContext.saveGraphicsState()
  NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
  let ctx = NSGraphicsContext.current!.cgContext
  ctx.setFillColor(NSColor.white.cgColor); ctx.fill(CGRect(x: 0, y: 0, width: w, height: h))
  ctx.scaleBy(x: CGFloat(w) / r.width, y: CGFloat(h) / r.height)
  p.draw(with: .mediaBox, to: ctx)
  NSGraphicsContext.restoreGraphicsState()
  let data = rep.representation(using: .jpeg, properties: [.compressionFactor: 0.8])!
  try! data.write(to: URL(fileURLWithPath: "\(out)/p\(String(format: "%02d", i + 1)).jpg"))
}
print(doc.pageCount)
