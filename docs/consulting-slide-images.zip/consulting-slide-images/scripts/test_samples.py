"""Bundled sample decks: index integrity and use as references without a library."""
import json, subprocess, sys, tempfile, unittest
from pathlib import Path
import knowledge
SCRIPT=Path(__file__).with_name('harness.py')
class SampleTests(unittest.TestCase):
 def call(self,*args):return subprocess.run([sys.executable,str(SCRIPT),*map(str,args)],capture_output=True,text=True)
 def test_index_complete(self):
  sm=knowledge.load_samples();self.assertTrue(sm['decks'])
  for d in sm['decks']:
   if d['pdf_path']: self.assertTrue(Path(d['pdf_path']).is_file())
   self.assertEqual(len(d['pages']),d['page_count'])
  for x in sm['items']:
   self.assertTrue(Path(x['image']).is_file(),x['id'])
   for k in ['message','relationship','expression','adopt']:self.assertTrue(x[k],x['id'])
 def test_search(self):
  out=json.loads(self.call('samples','--query','循環','--limit',3).stdout);self.assertTrue(out['candidates']);self.assertLessEqual(len(out['candidates']),3)
 def test_sample_reference_without_library(self):
  with tempfile.TemporaryDirectory() as t:
   run=Path(t)/'run';self.call('init',run);self.call('lock-purpose',run)
   sid=knowledge.load_samples()['items'][0]['id']
   p=run/'brief.json';b=json.loads(p.read_text());b['knowledge_library']=str(Path(t)/'missing')
   b['slides'][0]['reference']=sid
   b['slides'][0]['knowledge_use'].update(mode='adapt',references=[{'id':sid,'adopt':'構造','avoid':'本文・数値の転用','score_consideration':'採点なしの同梱見本','purpose_fit':{'reader_task':'理解','relationship':'循環','detail_level':'同等','helps_understand':'役割分担','suitable':True}}])
   p.write_text(json.dumps(b));r=self.call('build',run);self.assertEqual(r.returncode,0,r.stderr)
   build=sorted((run/'builds').iterdir())[-1]
   snap=json.loads((build/'knowledge-snapshot.json').read_text());self.assertEqual(snap['slides']['1']['references'][0]['evidence']['score_source'],'bundled_sample')
   self.assertTrue(Path(json.loads((build/'manifest.json').read_text())['references']['1']).is_file())
   b['slides'][0]['knowledge_use']['references'][0]['id']='no-such-page';p.write_text(json.dumps(b));self.assertNotEqual(self.call('build',run).returncode,0)
if __name__=='__main__':unittest.main()
