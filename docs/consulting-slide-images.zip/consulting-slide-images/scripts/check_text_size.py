#!/usr/bin/env python3
"""コード描画のスライドHTMLを実際に描画し、小さすぎる文字を検出する。

使い方: python3 check_text_size.py slide-01.html [slide-02.html ...] [--min 16] [--note-min 14]
- 1920x1080 基準。本文・図内のラベル・表・バッジを含むすべての可視テキストを測る（SVGの<text>も含む）。
- 注記・出典（class に note / foot / src を含む要素）だけ --note-min まで許容する。
- 画像に焼き込まれた文字は測れないので、目視で確認すること。
終了コード: 違反があれば 1。
"""
import sys, subprocess, json, re, os, tempfile
EDGE = "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
JS = r"""
<script>
window.addEventListener('load',()=>{setTimeout(()=>{
 const out=[];const isNote=e=>{for(let p=e;p;p=p.parentElement){const c=(p.getAttribute&&p.getAttribute('class'))||'';if(/(^|\s)(note|foot|src)(\s|$)/.test(c))return true;}return false;};
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
 while(n=walker.nextNode()){const t=n.textContent.trim();if(!t)continue;const e=n.parentElement;if(!e)continue;
  const cs=getComputedStyle(e);if(cs.display==='none'||cs.visibility==='hidden'||+cs.opacity===0)continue;
  let fs=parseFloat(cs.fontSize);
  const svg=e.closest('svg');if(svg&&e.getBoundingClientRect){const r=e.getBoundingClientRect();const box=e.getBBox?e.getBBox():null;if(box&&box.height>0){fs=fs*(r.height/box.height);}}
  const r=e.getBoundingClientRect();if(r.width===0||r.height===0)continue;
  out.push({t:t.slice(0,24),fs:Math.round(fs*10)/10,note:isNote(e)});}
 const pre=document.createElement('pre');pre.id='__fs';pre.textContent=JSON.stringify(out);document.body.appendChild(pre);
},300)});
</script>"""
def check(path, mn, nmn):
    html=open(path,encoding='utf8').read()
    tmp=os.path.join(os.path.dirname(os.path.abspath(path)),'.__fscheck.html')
    open(tmp,'w',encoding='utf8').write(html.replace('</body>',JS+'</body>') if '</body>' in html else html+JS)
    try:
        dom=subprocess.run([EDGE,'--headless=new','--disable-gpu','--window-size=1920,1080','--virtual-time-budget=3000','--dump-dom','file://'+tmp],capture_output=True,text=True,timeout=60).stdout
    finally:
        os.remove(tmp)
    m=re.search(r'<pre id="__fs">(.*?)</pre>',dom,re.S)
    if not m: return [("(測定できず)",0,False)]
    import html as H
    items=json.loads(H.unescape(m.group(1)))
    bad=[(i['t'],i['fs'],i['note']) for i in items if i['fs']<(nmn if i['note'] else mn)]
    return bad
def main():
    a=sys.argv[1:]; mn=16; nmn=14; files=[]
    i=0
    while i<len(a):
        if a[i]=='--min': mn=float(a[i+1]); i+=2
        elif a[i]=='--note-min': nmn=float(a[i+1]); i+=2
        else: files.append(a[i]); i+=1
    fail=False
    for f in files:
        bad=check(f,mn,nmn)
        if bad:
            fail=True; print(f"NG {f}: {len(bad)}件"); seen=set()
            for t,fs,nt in sorted(bad,key=lambda x:x[1]):
                k=(t,fs)
                if k in seen: continue
                seen.add(k); print(f"   {fs}px {'(注記)' if nt else ''} {t}")
        else: print(f"OK {f}")
    sys.exit(1 if fail else 0)
if __name__=='__main__': main()
