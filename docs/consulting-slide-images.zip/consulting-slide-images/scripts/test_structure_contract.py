import copy
import unittest
import structure_contract as s


def intake(size='multi'):
    row = lambda v, p='from_request': {'value': v, 'provenance': p}
    return {'deck_size': row(size), 'audience': row('executives'), 'audience_state': row('agreed on possibility'),
            'usage': row('projected in meeting', 'asked_user'), 'decision': row('align and Go'),
            'setting': row('30 min', 'assumed'), 'key_message': row('start the loop with one project', 'asked_user'),
            'expected_questions': row('why this project', 'asked_user')}


class StructureTests(unittest.TestCase):
    def setUp(self):
        self.brief = {'skill_version': 4, 'slides': [
            {'id': 1, 'title': 'Two forces are needed'}, {'id': 2, 'title': 'No proof yet'},
            {'id': 3, 'title': 'Prove it in one project'}, {'id': 4, 'title': 'Scale becomes an edge'}],
            'deck_design': {'version': 1, 'intake': intake(),
                'alternatives': [
                    {'id': 'A', 'summary': 'build-up', 'conclusion_position': 'last', 'pages': ['vision', 'gap', 'move', 'scale'], 'pros': 'story', 'cons': 'ask is late'},
                    {'id': 'B', 'summary': 'answer first', 'conclusion_position': 'first', 'pages': ['ask', 'gap', 'move', 'scale'], 'pros': 'fast', 'cons': 'abrupt'}],
                'chosen': 'A', 'choice_reason': 'readers need the whole picture first',
                'headline_chain': [{'slide_id': i, 'headline': t, 'receives': 'x', 'hands_off': 'y'} for i, t in
                                   [(1, 'Two forces are needed'), (2, 'No proof yet'), (3, 'Prove it in one project'), (4, 'Scale becomes an edge')]],
                'question_ledger': [{'question': 'Can AI people do SI?', 'raised_on': 2, 'answered_on': 3}],
                'slide_certainty': {'1': 'fact', '2': 'perception', '3': 'proposal', '4': 'hypothesis'},
                'ask': {'slide_id': 4, 'request': 'Go for the first project', 'basis': [2, 3]},
                'anticipated_questions': [{'question': 'why this project', 'handling': 'verbal'}],
                'motif': {'elements': ['purple=AI', 'navy=SI'], 'meaning': 'same colors on every page'}}}
        self.review = {'reviewer': 'agent', 'headlines_only_read': 'two forces, no proof, prove it, scale',
                       'gates': dict.fromkeys(s.GATES, True), 'evidence': ['titles read as one story'], 'fixes': []}

    def test_legacy_without_v4(self):
        self.assertEqual(s.validate({'skill_version': 3, 'slides': [{'id': 1, 'title': 't'}]}), [])

    def test_v4_requires_design(self):
        del self.brief['deck_design']
        with self.assertRaises(ValueError): s.validate(self.brief)

    def test_pass_and_assumed_warning(self):
        warnings = s.validate(self.brief)
        self.assertIn('仮置きの前提: setting', warnings)
        self.assertTrue(s.review(self.brief, self.review))

    def test_unanswered_question(self):
        self.brief['deck_design']['question_ledger'][0]['answered_on'] = None
        with self.assertRaises(ValueError): s.validate(self.brief)

    def test_answer_before_question(self):
        self.brief['deck_design']['question_ledger'][0]['answered_on'] = 1
        with self.assertRaises(ValueError): s.validate(self.brief)

    def test_headline_must_match_title(self):
        self.brief['deck_design']['headline_chain'][1]['headline'] = 'Something else'
        with self.assertRaises(ValueError): s.validate(self.brief)

    def test_ask_not_only_on_hypothesis(self):
        self.brief['deck_design']['ask']['basis'] = [4]
        with self.assertRaises(ValueError): s.validate(self.brief)

    def test_multi_needs_two_alternatives(self):
        self.brief['deck_design']['alternatives'].pop()
        self.brief['deck_design']['chosen'] = 'A'
        with self.assertRaises(ValueError): s.validate(self.brief)

    def test_single_deck(self):
        b = copy.deepcopy(self.brief)
        b['slides'] = b['slides'][:1]
        d = b['deck_design']
        d['intake'] = intake('single')
        d['alternatives'] = d['alternatives'][:1]
        d['headline_chain'] = d['headline_chain'][:1]
        d['question_ledger'] = []
        d['slide_certainty'] = {'1': 'fact'}
        d['ask'] = {'slide_id': 1, 'request': 'understand', 'basis': [1]}
        s.validate(b)
        d['intake']['deck_size']['value'] = 'multi'
        with self.assertRaises(ValueError): s.validate(b)
        d['partial_scope'] = 'only page 1 of the 4-page plan this time'
        s.validate(b)

    def test_missing_intake_provenance(self):
        self.brief['deck_design']['intake']['usage']['provenance'] = 'guess'
        with self.assertRaises(ValueError): s.validate(self.brief)

    def test_open_question_warns(self):
        self.brief['deck_design']['anticipated_questions'][0]['handling'] = 'open'
        self.assertTrue(any('未対応' in w for w in s.validate(self.brief)))

    def test_false_gate_needs_fixes(self):
        self.review['gates']['questions_resolved'] = False
        with self.assertRaises(ValueError): s.review(self.brief, self.review)
        self.review['fixes'] = ['answer Q2 on page 3']
        self.assertFalse(s.review(self.brief, self.review))

    def test_unjudged_rejected(self):
        self.review['gates']['motif_consistent'] = None
        with self.assertRaises(ValueError): s.review(self.brief, self.review)


if __name__ == '__main__':
    unittest.main()
