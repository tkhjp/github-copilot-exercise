import unittest
import attention_contract as a


class AttentionTests(unittest.TestCase):
    def setUp(self):
        self.slide = {'attention_design': {'version': 1, 'entry_point': 'Title',
            'primary_focus': 'Cycle', 'hierarchy_strategy': 'Cycle large; notes quiet',
            'secondary_elements': ['Notes'], 'internal_only_checks': ['Evidence checks']}}
        self.result = {'attention_review': {'gates': dict.fromkeys(a.GATES, True),
            'first_glance_observation': 'Title then cycle', 'competing_elements': [],
            'evidence': ['Notes occupy less area and use lighter emphasis']}}

    def test_legacy(self):
        self.assertTrue(a.review({}, {}))

    def test_pass(self):
        self.assertTrue(a.review(self.slide, self.result))

    def test_missing_review(self):
        with self.assertRaises(ValueError): a.review(self.slide, {})

    def test_first_glance_distinct_from_detailed_read(self):
        self.result['attention_review']['first_glance_observation'] = ''
        with self.assertRaises(ValueError): a.review(self.slide, self.result)

    def test_false_fails_independently(self):
        for key in a.GATES:
            self.result['attention_review']['gates'] = dict.fromkeys(a.GATES, True)
            self.result['attention_review']['gates'][key] = False
            self.assertFalse(a.review(self.slide, self.result))

    def test_unjudged_rejected(self):
        self.result['attention_review']['gates']['entry_clear'] = None
        with self.assertRaises(ValueError): a.review(self.slide, self.result)


if __name__ == '__main__':
    unittest.main()
