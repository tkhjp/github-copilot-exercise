"""Check content records and coverage; never infer semantic correctness."""
from design_contract import text, strings

GATES = ('truthfulness', 'reasoning', 'audience_fit', 'cross_page_consistency',
         'instructions_followed', 'release_ready')


def rows(value, name, allow_empty=False):
    if not isinstance(value, list) or (not value and not allow_empty):
        raise ValueError(name + ' must be a list')
    if any(not isinstance(row, dict) for row in value):
        raise ValueError(name + ' entries must be objects')
    return value


def indexed(value, name, allow_empty=False):
    result = {}
    for row in rows(value, name, allow_empty):
        text(row.get('id'), name + '.id')
        if row['id'] in result:
            raise ValueError('Duplicate ' + name + ' id')
        result[row['id']] = row
    return result


def validate(brief):
    if 'content_contract' not in brief:
        return None
    c = brief['content_contract']
    if not isinstance(c, dict) or type(c.get('version')) is not int or c['version'] != 1:
        raise ValueError('content_contract needs version 1')
    ids = [s['id'] for s in brief['slides']]
    sources = indexed(c.get('sources'), 'sources')
    for source in sources.values():
        for key in ('locator', 'evidence'):
            text(source.get(key), 'source.' + key)
        if source.get('verification') not in ('user_provided', 'verified', 'unverified'):
            raise ValueError('Explicit source verification required')
    story = rows(c.get('storyline'), 'storyline')
    if [row.get('slide_id') for row in story] != ids:
        raise ValueError('Storyline must cover all slides in order exactly once')
    for row in story:
        for key in ('role', 'incoming', 'outgoing'):
            text(row.get(key), 'storyline.' + key)
    arguments = indexed(c.get('arguments'), 'arguments')
    for row in arguments.values():
        if row.get('slide_id') not in ids:
            raise ValueError('Unknown argument slide')
        for key in ('claim', 'warrant', 'qualification'):
            text(row.get(key), 'argument.' + key)
        strings(row.get('source_ids'), 'source_ids')
        if any(sid not in sources for sid in row['source_ids']):
            raise ValueError('Unknown evidence source')
    if {row['slide_id'] for row in arguments.values()} != set(ids):
        raise ValueError('Every slide needs a main argument')
    for row in indexed(c.get('instructions'), 'instructions').values():
        for key in ('text', 'reason'):
            text(row.get(key), 'instruction.' + key)
        strings(row.get('locations'), 'instruction.locations')
        target = row.get('slide_ids')
        if not isinstance(target, list) or not target or any(type(x) is not int or x not in ids for x in target):
            raise ValueError('Instruction must target existing slides')
        if row.get('disposition') not in ('applied', 'superseded', 'not_applicable'):
            raise ValueError('Unresolved instruction disposition')
    checks = indexed(c.get('role_checks'), 'role_checks', allow_empty=True)
    for row in checks.values():
        if row.get('slide_id') not in ids or type(row.get('applicable')) is not bool:
            raise ValueError('Invalid role check scope/applicability')
        for key in ('topic', 'reason', 'details'):
            text(row.get(key), 'role_check.' + key)
    return c


def template():
    return {'gates': dict.fromkeys(GATES), 'arguments': [], 'instructions': [],
            'role_checks': [], 'observations': []}


def review(brief, result):
    c = validate(brief)
    if c is None:
        return True  # Historical runs stay readable and reviewable.
    r = result.get('content_review')
    if not isinstance(r, dict):
        raise ValueError('content_review required')
    gates = r.get('gates', {})
    if not isinstance(gates, dict) or any(type(gates.get(k)) is not bool for k in GATES):
        raise ValueError('Explicit content review gates required')
    strings(r.get('observations'), 'content_review.observations')
    accepted = all(gates[k] for k in GATES)
    for key, verdict in [('arguments', 'supported'), ('instructions', 'satisfied'), ('role_checks', 'met')]:
        expected = {x['id'] for x in c[key] if key != 'role_checks' or x['applicable']}
        actual = indexed(r.get(key), 'review.' + key, allow_empty=True)
        if set(actual) != expected:
            raise ValueError('Review coverage mismatch: ' + key)
        for row in actual.values():
            if type(row.get(verdict)) is not bool:
                raise ValueError('Explicit ' + verdict + ' required')
            text(row.get('evidence'), 'review evidence')
            accepted = accepted and row[verdict]
    return accepted
