import copy
import unittest
import content_contract as c


def fixture():
    return {'slides': [{'id': 1}], 'content_contract': {
        'version': 1,
        'sources': [{'id': 's1', 'locator': 'User brief section 2',
                     'evidence': 'Proposed model', 'verification': 'user_provided'}],
        'storyline': [{'slide_id': 1, 'role': 'Model', 'incoming': 'Problem', 'outgoing': 'Understand roles'}],
        'arguments': [{'id': 'a1', 'slide_id': 1, 'claim': 'Human decides',
                       'source_ids': ['s1'], 'warrant': 'AI supplies drafts', 'qualification': 'Target state'}],
        'instructions': [{'id': 'i1', 'text': 'Mark target state', 'slide_ids': [1],
                          'locations': ['Footer'], 'disposition': 'applied', 'reason': 'Requested'}],
        'role_checks': [{'id': 'r1', 'slide_id': 1, 'topic': 'Schedule', 'applicable': False,
                         'reason': 'Concept only', 'details': 'Do not invent dates'}]}}


def review_fixture():
    return {'content_review': {
        'gates': dict.fromkeys(c.GATES, True),
        'arguments': [{'id': 'a1', 'supported': True, 'evidence': 'Human decision shown at handoff'}],
        'instructions': [{'id': 'i1', 'satisfied': True, 'evidence': 'Footer says target state'}],
        'role_checks': [], 'observations': ['Inspected final image and brief']}}


class ContentTests(unittest.TestCase):
    def test_legacy_compatibility(self):
        self.assertTrue(c.review({'slides': [{'id': 1}]}, {}))

    def test_complete_and_not_applicable(self):
        self.assertTrue(c.review(fixture(), review_fixture()))

    def test_broken_evidence_reference(self):
        b = fixture(); b['content_contract']['arguments'][0]['source_ids'] = ['missing']
        with self.assertRaises(ValueError): c.validate(b)

    def test_story_must_cover_new_page(self):
        b = fixture(); b['slides'].append({'id': 2})
        with self.assertRaises(ValueError): c.validate(b)

    def test_missing_instruction_review(self):
        r = review_fixture(); r['content_review']['instructions'] = []
        with self.assertRaises(ValueError): c.review(fixture(), r)

    def test_duplicate_reviews(self):
        r = review_fixture(); r['content_review']['arguments'] *= 2
        with self.assertRaises(ValueError): c.review(fixture(), r)

    def test_false_cannot_be_offset(self):
        for key in c.GATES:
            r = review_fixture(); r['content_review']['gates'][key] = False
            self.assertFalse(c.review(fixture(), r))
        r = review_fixture(); r['content_review']['arguments'][0]['supported'] = False
        self.assertFalse(c.review(fixture(), r))

    def test_unjudged_rejected(self):
        r = review_fixture(); r['content_review']['gates']['reasoning'] = None
        with self.assertRaises(ValueError): c.review(fixture(), r)

    def test_applicable_role_requires_review(self):
        b = fixture(); b['content_contract']['role_checks'][0]['applicable'] = True
        with self.assertRaises(ValueError): c.review(b, review_fixture())


if __name__ == '__main__':
    unittest.main()
