import unittest
import glance_contract as g


class GlanceTests(unittest.TestCase):
    def setUp(self):
        self.slide = {'glance_design': {'version': 1,
            'glance_message': 'AI runs the loop; people talk with the client',
            'glance_structure': 'Large AI cycle with a human dialogue zone attached',
            'why_structure_says_it': 'Cycle size shows AI continuity; person zone shows focus',
            'density_floor': ['Six cycle steps with one-line actions']}}
        self.result = {'glance_review': {'gates': dict.fromkeys(g.GATES, True),
            'glance_read': 'AI keeps the cycle, people own the dialogue',
            'kept_details': ['All six steps remain'], 'evidence': ['Cycle occupies the center']}}

    def test_legacy(self):
        self.assertTrue(g.review({}, {}))

    def test_v3_requires_design(self):
        with self.assertRaises(ValueError): g.validate({'skill_version': 3, 'slides': [{}]})
        g.validate({'skill_version': 2, 'slides': [{}]})

    def test_pass(self):
        self.assertTrue(g.review(self.slide, self.result))

    def test_glance_read_required(self):
        self.result['glance_review']['glance_read'] = ''
        with self.assertRaises(ValueError): g.review(self.slide, self.result)

    def test_density_floor_required(self):
        self.slide['glance_design']['density_floor'] = []
        with self.assertRaises(ValueError): g.check(self.slide)

    def test_false_fails_independently(self):
        for key in g.GATES:
            self.result['glance_review']['gates'] = dict.fromkeys(g.GATES, True)
            self.result['glance_review']['gates'][key] = False
            self.assertFalse(g.review(self.slide, self.result))

    def test_unjudged_rejected(self):
        self.result['glance_review']['gates']['density_kept'] = None
        with self.assertRaises(ValueError): g.review(self.slide, self.result)


if __name__ == '__main__':
    unittest.main()
