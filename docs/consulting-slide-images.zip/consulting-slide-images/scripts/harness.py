#!/usr/bin/env python3
"""Local orchestration only: no network, API calls, or automatic visual verdicts."""
import argparse, hashlib, json, shutil, sys
from pathlib import Path
from datetime import datetime, timezone
import knowledge
import design_contract
import content_contract
import attention_contract
import glance_contract
import structure_contract
ROOT = Path(__file__).resolve().parents[1]
GATES = ['text_exact','claims_grounded','relationships_correct','legible','reference_fidelity']
SCORES = ['explanation','diagram','hierarchy','density','usefulness']
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,d): Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def resolve_ref(name):
 # Absolute path, path under assets/, or a bundled sample page id such as 'synapselink-p03'.
 ref=Path(name)
 if ref.is_absolute(): return ref
 if (ROOT/'assets'/ref).is_file(): return ROOT/'assets'/ref
 page={x['id']:x for x in knowledge.load_samples()['items']}.get(str(name))
 return Path(page['image']) if page else ROOT/'assets'/ref
def validate(b):
 for k in ['audience','purpose','slides']:
  if not b.get(k): raise ValueError('Missing '+k)
 if not isinstance(b['slides'],list): raise ValueError('slides must be a list')
 ids=set(); warnings=[]
 for s in b['slides']:
  sid=s.get('id');
  if type(sid)!=int or sid<1 or sid in ids: raise ValueError('Slide ids must be unique positive integers')
  ids.add(sid)
  for k in ['title','takeaway','layout','blocks','diagram','claims']:
   if not s.get(k): raise ValueError(f'Slide {sid}: missing {k}')
  if s.get('reference'):
   if not resolve_ref(s['reference']).is_file(): raise ValueError('Reference image not found')
  use=s.get('knowledge_use')
  if use is None: warnings.append(f'{sid}: knowledge_use未記載。主張・参照・独自設計の理由を記録する')
  else:
   if use.get('mode') not in ['original','adapt','combine']: raise ValueError('Invalid knowledge_use mode')
   for key in ['reader_action','pattern','rationale','novel_design']:
    if not isinstance(use.get(key),str) or not use[key].strip(): raise ValueError('knowledge_use needs '+key)
   refs=use.get('references',[])
   if not isinstance(refs,list): raise ValueError('references must be a list')
   if use['mode'] in ['adapt','combine'] and not refs: raise ValueError('Adapt/combine needs reference decisions')
   for ref in refs:
    for key in ['id','adopt','avoid','score_consideration']:
     if not ref.get(key): raise ValueError('Reference decision needs '+key)
  if len(s['blocks'])<2: warnings.append(f'{sid}: 説明論点が少ない。図内説明と合わせて検討')
  for block in s['blocks']:
   if not block.get('heading') or not block.get('body'): raise ValueError('Each block needs heading and explanatory body')
  for c in s['claims']:
   if c.get('status') not in ['fact','proposal','perception']: raise ValueError('Invalid claim status')
   if not c.get('text') or not c.get('source'): raise ValueError('Every claim needs text and source')
  d=s['diagram']; nodes=d.get('nodes',[]); nodeids=[n['id'] for n in nodes]
  if len(nodeids)!=len(set(nodeids)) or not nodes: raise ValueError('Invalid diagram nodes')
  for n in nodes:
   if not n.get('label') or not n.get('detail'): raise ValueError('Diagram nodes need labels and explanatory details')
  for e in d.get('edges',[]):
   if e.get('from') not in nodeids or e.get('to') not in nodeids or not e.get('label'): raise ValueError('Invalid diagram edge')
 return warnings
def skeleton():
 return {'audience':'SI・AI両リーダー','purpose':'実案件を通じた人材循環の構想を議論する','palette':'白・黒・紫 #A100FF','slides':[{'id':1,'title':'SIとAIの循環でASI人材を育てる','takeaway':'案件成果と育成を両リーダーで進め、次案件へ展開する','layout':'左に理由と役割の説明、右に双方向の循環、下に再配置','reference':None,'blocks':[{'heading':'AI人材のSI参画','body':'初期の試作から後半の実装まで関わり、SIの品質・本番導入を学ぶ。'},{'heading':'SI人材のAI育成','body':'配置転換する人材をAIチームで受け入れ、実案件を通じてAIスキルを身につける。'},{'heading':'次の案件へ展開','body':'SIとAIの両方を理解する人材と、有効だった進め方を次の案件へ展開する。'}],'diagram':{'nodes':[{'id':'si','label':'SIチーム','detail':'業務・品質・本番導入を実践'},{'id':'ai','label':'AIチーム','detail':'AIの実装・検証を実務で育成'},{'id':'next','label':'次案件','detail':'育った人材と進め方を展開'}],'edges':[{'from':'ai','to':'si','label':'AI人材が参画し、SIを学ぶ'},{'from':'si','to':'ai','label':'配置転換する人材を育成'},{'from':'ai','to':'next','label':'育った人材を再配置'}]},'claims':[{'text':'SI・AI両チームの協力でSECOMから循環を始めたい','status':'proposal','source':'ユーザーの10/6メモ'}],'footnote':'ASIは本構想の呼称。具体的な育成方法・体制は検討する。'}]}
def main():
 ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='cmd',required=True)
 x=sub.add_parser('knowledge');x.add_argument('--library',default=str(knowledge.DEFAULT_LIBRARY));x.add_argument('--query',default='');x.add_argument('--limit',type=int,default=12);x.add_argument('--output')
 x=sub.add_parser('samples');x.add_argument('--query',default='');x.add_argument('--limit',type=int,default=12)
 x=sub.add_parser('init');x.add_argument('run')
 x=sub.add_parser('lock-purpose');x.add_argument('run');x.add_argument('--reason')
 x=sub.add_parser('build');x.add_argument('run')
 x=sub.add_parser('review-template');x.add_argument('output')
 x=sub.add_parser('record');x.add_argument('run');x.add_argument('--slide',type=int,required=True);x.add_argument('--image',required=True);x.add_argument('--review',required=True);x.add_argument('--prompt',required=True)
 x=sub.add_parser('status');x.add_argument('run')
 x=sub.add_parser('deck-review-template');x.add_argument('output')
 x=sub.add_parser('review-deck');x.add_argument('run');x.add_argument('--review',required=True)
 a=ap.parse_args()
 if a.cmd=='knowledge':
  data=knowledge.load(a.library)
  if a.output:
   dest=Path(a.output).resolve()
   if dest in [Path(a.library).resolve()/x for x in ['catalog.json','baseline-reviews.json','reviews/ratings.json','knowledge-labels.json']]: raise ValueError('Cannot overwrite library source data')
   write(dest,data)
  result=knowledge.search(data,a.query)[:max(0,a.limit)]
  print(json.dumps({'confirmed_count':len(data['items']),'ratings_saved_at':data['ratings_saved_at'],'candidates':result},ensure_ascii=False,indent=2));return
 if a.cmd=='samples':
  sm=knowledge.load_samples()
  print(json.dumps({'decks':[{k:d.get(k) for k in ['id','title','pdf_path','storyline','page_count']} for d in sm['decks']],'candidates':knowledge.search_samples(sm,a.query)[:max(0,a.limit)]},ensure_ascii=False,indent=2));return
 if a.cmd=='review-template':
  out=Path(a.output)
  if out.exists(): raise ValueError('Refusing to overwrite review')
  write(out,{'reviewer':'','observations':[],'fixes':[], 'gates':dict.fromkeys(GATES,None),'scores':dict.fromkeys(SCORES,None),'quality_review':{'content_sufficient':None,'reading_path_clear':None,'structure_simple':None,'decoration_supportive':None,'relationship_clear':None,'focal_supports_message':None,'evidence':[]},'purpose_review':{'outcome_met':None,'arguments_preserved':None,'scope_respected':None,'evidence':[]},'attention_review':attention_contract.template(), 'glance_review':glance_contract.template(), 'content_review':content_contract.template(), 'comparison':{'baseline_sha256':None,'improvements':[],'regressions':[],'choice':None,'reason':''}});return
 if a.cmd=='deck-review-template':
  out=Path(a.output)
  if out.exists(): raise ValueError('Refusing to overwrite review')
  write(out,structure_contract.template());return
 run=Path(a.run).resolve()
 if a.cmd=='init':
  run.mkdir(parents=True,exist_ok=True)
  if (run/'brief.json').exists(): raise ValueError('Existing brief; use a new folder')
  sample=skeleton()
  sample['slides'][0]['reference']=None
  sample['slides'][0]['knowledge_use']={'mode':'original','reader_action':'SI・AI両リーダーが人材循環の着手を議論する','pattern':'人材の移動と習得経験の対応','rationale':'人材の移動・学習・再配置を具体的に説明するため。依頼に合わせて置換する。','novel_design':'今回の案件工程と人材の習得経験を対応づける。','references':[]}
  sample['slides'][0]['objective']={'page_role':'人材循環の仕組みを説明する','reader_outcome':'SI・AIの相互育成と次案件への展開を理解する','thesis':'実案件の相互育成でASI人材を増やす','required_arguments':['AI人材のSI経験','SI人材のAI育成','次案件への展開'],'out_of_scope':['具体的な配置人数・日程']}
  sample['slides'][0]['revision']={'mode':'new'}
  write(run/'brief.json',sample);print('Created sample brief; replace with authorized task content.');return
 b=read(run/'brief.json')
 if a.cmd=='review-deck':
  # Structure is reviewed before pages are designed: only ids and titles are needed.
  if not isinstance(b.get('slides'),list) or not b['slides'] or any(type(x.get('id'))!=int or not x.get('title') for x in b['slides']): raise ValueError('Each slide needs id and title')
  warnings=[]
 else: warnings=validate(b)
 if a.cmd=='lock-purpose':
  print(json.dumps({'purpose_lock':str(design_contract.lock(run,b,a.reason))},ensure_ascii=False));return
 if a.cmd=='build':
  content_contract.validate(b)
  attention_contract.validate(b)
  glance_contract.validate(b)
  warnings+=structure_contract.validate(b)
  purpose_lock=design_contract.check(run,b)
  # Resolve live ratings, never trust hand-entered or stale scores.
  samples={x['id']:x for x in knowledge.load_samples()['items']}
  decisions={};needs_library=any(r['id'] not in samples for sl in b['slides'] for r in sl.get('knowledge_use',{}).get('references',[]))
  kb=knowledge.load(b.get('knowledge_library',knowledge.DEFAULT_LIBRARY)) if needs_library else None
  lookup=dict(samples,**({x['id']:x for x in kb['items']} if kb else {}))
  for sl in b['slides']:
   resolved=[]
   for decision in sl.get('knowledge_use',{}).get('references',[]):
    rid=decision['id']
    if rid not in lookup: raise ValueError('Reference excluded, unconfirmed or missing: '+rid)
    resolved.append({'decision':decision,'evidence':lookup[rid]})
   decisions[str(sl['id'])]={'design':sl.get('knowledge_use'),'references':resolved}
  # Immutable prompt snapshots: each build gets a new directory.
  root=run/'builds';root.mkdir(exist_ok=True);number=1
  while (root/f'{number:03d}').exists(): number+=1
  out=root/f'{number:03d}';out.mkdir()
  write(out/'brief.json',b)
  shutil.copy2(purpose_lock,out/'purpose-lock.json')
  write(out/'knowledge-snapshot.json',{'ratings_saved_at':kb.get('ratings_saved_at') if kb else None,'slides':decisions})
  design=(ROOT/'references/design.md').read_text()
  for s in b['slides']:
   prompt='Create a finished Japanese consulting slide image, landscape 16:9, high-resolution.\n'
   prompt+='Reference image is STYLE ONLY; do not borrow its claims, numbers or company names.\n'
   prompt+='Use exact approved copy below. Diagram relations are semantic instructions; render their labels and details, not JSON keys.\n'
   prompt+='Render title, takeaway, block headings/bodies, diagram labels/details/edge labels, and footnote. layout/reference/claims/id/knowledge_use/objective/revision/quality_design/content_contract/attention_design/glance_design are production metadata, not literal slide text; use claims only to preserve epistemic status and source attribution. Do not render the design guidance itself.\n'
   prompt+='The library is an open knowledge base, not an exhaustive set of layouts. Invent or combine structures when they better serve this claim. Do not force the message into a reference. User scores guide which aspects to adopt or avoid; they are not facts for the slide.\n'
   if s.get('knowledge_use'):
    prompt+='Design decision (production metadata, never render):\n'+json.dumps({'design':s['knowledge_use'],'reference_scores':[{'id':r['evidence']['id'],'scores':r['evidence']['scores'],'aggregate':r['evidence']['aggregate'],'score_source':r['evidence']['score_source']} for r in decisions[str(s['id'])]['references']]},ensure_ascii=False)+'\n'
   prompt+='Do not invent claims. Show proposals as 案 and perceptions as 問題認識.\n'
   if b.get('deck_design'):
    prompt+='Deck structure (production metadata, do not render):\n'+json.dumps({k:b['deck_design'][k] for k in ['headline_chain','motif']},ensure_ascii=False)+'\n'
   prompt+=f"Audience: {b['audience']}\nPurpose: {b['purpose']}\nPalette: {b.get('palette','白・黒・紫 #A100FF')}\n"
   if b.get('content_contract'):
    prompt+='Content decisions (production metadata, do not render):\n'+json.dumps(b['content_contract'],ensure_ascii=False)+'\n'
   prompt+='Design guidance:\n'+design+'\nSlide specification:\n'+json.dumps(s,ensure_ascii=False,indent=2)
   (out/f"slide-{s['id']:02d}.txt").write_text(prompt,encoding='utf-8')
  write(out/'manifest.json',{'brief_sha256':digest(out/'brief.json'),'warnings':warnings,'references':{str(s['id']):(str(resolve_ref(s['reference'])) if s.get('reference') else None) for s in b['slides']}})
  print(json.dumps({'build':str(out),'warnings':warnings},ensure_ascii=False));return
 if a.cmd=='record':
  if a.slide not in [s['id'] for s in b['slides']]: raise ValueError('Unknown slide')
  purpose_lock=design_contract.check(run,b)
  slide=next(s for s in b['slides'] if s['id']==a.slide)
  im=Path(a.image);pr=Path(a.prompt);r=read(a.review)
  if not im.is_file() or im.suffix.lower() not in ['.png','.jpg','.jpeg']: raise ValueError('Image file required')
  if not pr.is_file(): raise ValueError('Actual generation prompt required')
  sig=im.read_bytes()[:8]
  if not (sig.startswith(b'\x89PNG\r\n\x1a\n') or sig.startswith(b'\xff\xd8\xff')): raise ValueError('Invalid image signature')
  if not r.get('reviewer') or not isinstance(r.get('observations'),list) or not r['observations']: raise ValueError('Reviewer and visual observations required')
  if not isinstance(r.get('fixes'),list): raise ValueError('fixes must be a list')
  g=r.get('gates',{});scores=r.get('scores',{})
  if any(type(g.get(k)) is not bool for k in GATES): raise ValueError('All visual gates need explicit booleans')
  if any(type(scores.get(k)) is not int or not 0<=scores[k]<=2 for k in SCORES): raise ValueError('Scores must be integers 0–2')
  purpose_passed=design_contract.review(slide,r)
  content_passed=content_contract.review(b,r)
  attention_passed=attention_contract.review(slide,r)
  glance_passed=glance_contract.review(slide,r,glance_contract.required(b))
  passed=purpose_passed and content_passed and attention_passed and glance_passed and all(g[k] for k in GATES) and min(scores[k] for k in SCORES)>=1 and sum(scores[k] for k in SCORES)>=8
  if not passed and not r['fixes']: raise ValueError('Revision needs actionable fixes')
  folder=run/f'slide-{a.slide:02d}';folder.mkdir(exist_ok=True);v=1
  while (folder/f'v{v:02d}').exists():v+=1
  dest=folder/f'v{v:02d}';dest.mkdir()
  shutil.copy2(purpose_lock,dest/'purpose-lock.json')
  shutil.copy2(im,dest/('image'+im.suffix.lower()));shutil.copy2(pr,dest/'prompt.txt');shutil.copy2(run/'brief.json',dest/'brief.json')
  r.update({'verdict':'pass' if passed else 'revise','image_sha256':digest(im),'prompt_sha256':digest(pr),'brief_sha256':digest(run/'brief.json'),'time':datetime.now(timezone.utc).isoformat()})
  write(dest/'review.json',r);print(json.dumps({'version':str(dest),'verdict':r['verdict']},ensure_ascii=False));return
 if a.cmd=='review-deck':
  r=read(a.review);passed=structure_contract.review(b,r)
  folder=run/'deck';folder.mkdir(exist_ok=True);v=1
  while (folder/f'v{v:02d}').exists():v+=1
  dest=folder/f'v{v:02d}';dest.mkdir();shutil.copy2(run/'brief.json',dest/'brief.json')
  r.update({'verdict':'pass' if passed else 'revise','brief_sha256':digest(run/'brief.json'),'time':datetime.now(timezone.utc).isoformat()})
  write(dest/'review.json',r);print(json.dumps({'deck_review':str(dest),'verdict':r['verdict']},ensure_ascii=False));return
 if a.cmd=='status':
  result=[]
  if structure_contract.required(b) or b.get('deck_design'):
   decks=sorted((run/'deck').glob('v*/review.json'))
   if not decks:result.append({'deck':'structure','state':'not_reviewed'})
   else:
    r=read(decks[-1]);result.append({'deck':'structure','state':'stale_brief' if r['brief_sha256']!=digest(run/'brief.json') else r['verdict'],'review':str(decks[-1])})
  for s in b['slides']:
   versions=sorted((run/f"slide-{s['id']:02d}").glob('v*/review.json'))
   if not versions:result.append({'slide':s['id'],'state':'not_reviewed'});continue
   r=read(versions[-1]);state=r['verdict']
   if r['brief_sha256']!=digest(run/'brief.json'):state='stale_brief'
   images=list(versions[-1].parent.glob('image.*'))
   if len(images)!=1 or digest(images[0])!=r['image_sha256']:state='image_changed'
   promptfile=versions[-1].parent/'prompt.txt'
   if not promptfile.exists() or digest(promptfile)!=r['prompt_sha256']:state='prompt_changed'
   result.append({'slide':s['id'],'state':state,'review':str(versions[-1])})
  print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':
 try:main()
 except (ValueError,KeyError,TypeError,OSError,json.JSONDecodeError) as e:print('ERROR: '+str(e),file=sys.stderr);sys.exit(1)
