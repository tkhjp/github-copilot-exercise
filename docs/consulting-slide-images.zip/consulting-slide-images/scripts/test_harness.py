"""Regression tests for orchestration; synthetic review scores are NOT image QA."""
import base64, json, subprocess, sys, tempfile, unittest
from pathlib import Path
SCRIPT=Path(__file__).with_name('harness.py')
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')
class HarnessTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();global ASSET;ASSET=Path(self.tmp.name)/'sample.png';ASSET.write_bytes(PNG);self.run=Path(self.tmp.name)/'run';self.call('init',self.run);self.call('lock-purpose',self.run);self.call('build',self.run)
  self.prompt=self.run/'builds/001/slide-01.txt';self.review=self.run/'review.json'
 def tearDown(self): self.tmp.cleanup()
 def call(self,*args,ok=True):
  r=subprocess.run([sys.executable,str(SCRIPT),*map(str,args)],capture_output=True,text=True)
  self.assertEqual(r.returncode==0,ok,r.stderr);return r.stdout
 def data(self):
  return {'reviewer':'synthetic test fixture, not visual QA','observations':['Test state handling only'],'fixes':[], 'gates':dict.fromkeys(['text_exact','claims_grounded','relationships_correct','legible','reference_fidelity'],True),'purpose_review':{'outcome_met':True,'arguments_preserved':True,'scope_respected':True,'evidence':['Synthetic fixture only']},'scores':dict.fromkeys(['explanation','diagram','hierarchy','density','usefulness'],2)}
 def record(self,r,ok=True):
  self.review.write_text(json.dumps(r));return self.call('record',self.run,'--slide',1,'--image',ASSET,'--review',self.review,'--prompt',self.prompt,ok=ok)
 def test_unreviewed_and_immutable_build(self):
  self.assertEqual(json.loads(self.call('status',self.run))[0]['state'],'not_reviewed')
  old=self.prompt.read_bytes();self.call('build',self.run);self.assertEqual(old,self.prompt.read_bytes());self.assertTrue((self.run/'builds/002/slide-01.txt').exists())
 def test_no_source_and_bad_edges_rejected(self):
  p=self.run/'brief.json';b=json.loads(p.read_text());b['slides'][0]['claims'][0]['source']='';p.write_text(json.dumps(b));self.call('build',self.run,ok=False)
  b['slides'][0]['claims'][0]['source']='user';b['slides'][0]['diagram']['edges'][0]['to']='unknown';p.write_text(json.dumps(b));self.call('build',self.run,ok=False)
 def test_empty_review_rejected(self):
  self.call('review-template',self.review);r=json.loads(self.review.read_text());self.record(r,ok=False)
 def test_failed_gate_overrides_high_scores(self):
  r=self.data();r['gates']['text_exact']=False;r['fixes']=['Correct missing glyph'];out=json.loads(self.record(r));self.assertEqual(out['verdict'],'revise')
 def test_version_and_stale_detection(self):
  self.record(self.data());self.record(self.data());state=json.loads(self.call('status',self.run))[0];self.assertEqual(state['state'],'pass');self.assertIn('v02',state['review'])
  p=self.run/'brief.json';b=json.loads(p.read_text());b['slides'][0]['title']='変更';p.write_text(json.dumps(b));self.assertEqual(json.loads(self.call('status',self.run))[0]['state'],'stale_brief')
 def test_image_tamper_detected(self):
  self.record(self.data());(self.run/'slide-01/v01/image.jpg').write_bytes(b'changed');self.assertEqual(json.loads(self.call('status',self.run))[0]['state'],'image_changed')
 def test_missing_or_changed_purpose_rejected(self):
  lock=self.run/'purpose-locks/001.json';original=lock.read_bytes();lock.unlink()
  self.call('build',self.run,ok=False);lock.write_bytes(original)
  p=self.run/'brief.json';b=json.loads(p.read_text());b['slides'][0]['objective']['thesis']='Changed thesis';p.write_text(json.dumps(b))
  self.call('build',self.run,ok=False);self.call('lock-purpose',self.run,ok=False)
  self.call('lock-purpose',self.run,'--reason','User changed the scope');self.call('build',self.run)
  self.assertEqual(lock.read_bytes(),original)
 def test_score_cannot_override_purpose_failure(self):
  r=self.data();del r['purpose_review'];self.record(r,ok=False)
  r=self.data();r['purpose_review']['outcome_met']=False;r['fixes']=['Restore core argument']
  self.assertEqual(json.loads(self.record(r))['verdict'],'revise')
 def test_revision_comparison_and_baseline_change(self):
  import hashlib
  baseline=self.run/'baseline.jpg';baseline.write_bytes(ASSET.read_bytes())
  p=self.run/'brief.json';b=json.loads(p.read_text());b['slides'][0]['revision']={'mode':'revise','baseline_image':str(baseline),'preserve':['Core argument'],'change':['Smaller icons']};p.write_text(json.dumps(b))
  self.call('lock-purpose',self.run,'--reason','Exercise revision');self.call('build',self.run)
  self.record(self.data(),ok=False)
  r=self.data();r['comparison']={'baseline_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'improvements':[],'regressions':['Weaker argument'],'choice':'baseline','reason':'Baseline meets the objective better'};r['fixes']=['Restore core argument']
  self.assertEqual(json.loads(self.record(r))['verdict'],'revise')
  r['comparison'].update(choice='candidate',improvements=['Clearer emphasis'],regressions=[]);r['fixes']=[]
  self.assertEqual(json.loads(self.record(r))['verdict'],'pass')
  baseline.write_bytes(b'changed');self.call('build',self.run,ok=False)
if __name__=='__main__':unittest.main()
