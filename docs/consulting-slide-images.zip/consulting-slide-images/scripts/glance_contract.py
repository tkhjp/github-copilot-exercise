"""Validate glance decisions (V3); cannot judge whether a glance really conveys the thesis."""
from design_contract import text, strings

GATES = ('glance_matches_thesis', 'structure_carries_message', 'density_kept')


def required(brief):
    return type(brief.get('skill_version')) is int and brief['skill_version'] >= 3


def check(slide, need=False):
    if 'glance_design' not in slide:
        if need:
            raise ValueError('skill_version 3 requires glance_design')
        return False
    d = slide['glance_design']
    if not isinstance(d, dict) or type(d.get('version')) is not int or d['version'] != 1:
        raise ValueError('glance_design requires version 1')
    for key in ('glance_message', 'glance_structure', 'why_structure_says_it'):
        text(d.get(key), 'glance_design.' + key)
    strings(d.get('density_floor'), 'glance_design.density_floor')
    return True


def validate(brief):
    need = required(brief)
    for slide in brief['slides']:
        check(slide, need)


def template():
    return {'gates': dict.fromkeys(GATES), 'glance_read': '', 'kept_details': [], 'evidence': []}


def review(slide, result, need=False):
    if not check(slide, need):
        return True
    r = result.get('glance_review')
    if not isinstance(r, dict):
        raise ValueError('glance_review required')
    gates = r.get('gates', {})
    if not isinstance(gates, dict) or any(type(gates.get(k)) is not bool for k in GATES):
        raise ValueError('Explicit glance gates required')
    text(r.get('glance_read'), 'glance_read')
    strings(r.get('kept_details'), 'glance_review.kept_details')
    strings(r.get('evidence'), 'glance_review.evidence')
    return all(gates[k] for k in GATES)
