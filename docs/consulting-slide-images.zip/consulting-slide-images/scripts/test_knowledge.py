import json,tempfile,unittest,subprocess,sys
from pathlib import Path
import knowledge
SCRIPT=Path(__file__).with_name('harness.py')
class KnowledgeTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.p=Path(self.tmp.name);self.lib=self.p/'lib';self.lib.mkdir();(self.lib/'reviews').mkdir()
  self.catalog=[{'id':str(n),'path':str(n),'src':'slide.png','text':'循環'} for n in range(3)]
  self.base={'rubric':list('abcdef'),'items':{str(n):{'eligible':True,'scores':[4]*6} for n in range(3)}}
  self.r={'ratings':{'0':{'reviewed':True,'criteria':[5,4,3,2,1,4]},'1':{'reviewed':True,'eligible':False},'2':{'reviewed':False}}}
  for file,data in [('catalog.json',self.catalog),('baseline-reviews.json',self.base),('reviews/ratings.json',self.r)]: (self.lib/file).write_text(json.dumps(data))
 def tearDown(self):self.tmp.cleanup()
 def call(self,*args):return subprocess.run([sys.executable,str(SCRIPT),*map(str,args)],capture_output=True,text=True)
 def test_confirmed_and_live_scores(self):
  data=knowledge.load(self.lib);self.assertEqual([r['id'] for r in data['items']],['0']);self.assertEqual(data['items'][0]['scores'],[5,4,3,2,1,4]);self.assertEqual(data['items'][0]['label_status'],'needs_visual_labeling')
  self.assertEqual(knowledge.search(data,'不存在'),[])
 def test_original_and_live_exclusion(self):
  run=self.p/'run';self.assertEqual(self.call('init',run).returncode,0)
  self.assertEqual(self.call('lock-purpose',run).returncode,0)
  self.assertEqual(self.call('build',run).returncode,0) # no image/library needed
  p=run/'brief.json';b=json.loads(p.read_text());b['knowledge_library']=str(self.lib);b['slides'][0]['knowledge_use'].update(mode='adapt',references=[{'id':'0','adopt':'循環','avoid':'数値転用','score_consideration':'低い可読性は改善','purpose_fit':{'reader_task':'育成を理解','relationship':'循環','detail_level':'役割ごと','helps_understand':'次へ戻る経路','suitable':True}}]);p.write_text(json.dumps(b))
  ref=b['slides'][0]['knowledge_use']['references'][0];fit=ref.pop('purpose_fit');p.write_text(json.dumps(b));self.assertNotEqual(self.call('build',run).returncode,0)
  ref['purpose_fit']=dict(fit,suitable=False);p.write_text(json.dumps(b));self.assertNotEqual(self.call('build',run).returncode,0)
  ref['purpose_fit']=fit;p.write_text(json.dumps(b));self.assertEqual(self.call('build',run).returncode,0)
  snap=json.loads((run/'builds/002/knowledge-snapshot.json').read_text());self.assertEqual(snap['slides']['1']['references'][0]['evidence']['scores'],[5,4,3,2,1,4])
  self.r['ratings']['0']['eligible']=False;(self.lib/'reviews/ratings.json').write_text(json.dumps(self.r))
  self.assertNotEqual(self.call('build',run).returncode,0)
  self.assertFalse((run/'builds/003').exists())
 def test_source_protected(self):
  before=(self.lib/'reviews/ratings.json').read_bytes();r=self.call('knowledge','--library',self.lib,'--output',self.lib/'reviews/ratings.json');self.assertNotEqual(r.returncode,0);self.assertEqual(before,(self.lib/'reviews/ratings.json').read_bytes())
if __name__=='__main__':unittest.main()
