"""Validate attention decisions; does not measure eye movements or aesthetics."""
from design_contract import text, strings

GATES = ('entry_clear', 'primary_dominant', 'secondary_subordinate')


def check(slide):
    if 'attention_design' not in slide:
        return False
    d = slide['attention_design']
    if not isinstance(d, dict) or type(d.get('version')) is not int or d['version'] != 1:
        raise ValueError('attention_design requires version 1')
    for key in ('entry_point', 'primary_focus', 'hierarchy_strategy'):
        text(d.get(key), 'attention_design.' + key)
    for key in ('secondary_elements', 'internal_only_checks'):
        strings(d.get(key), 'attention_design.' + key, nonempty=False)
    return True


def validate(brief):
    for slide in brief['slides']:
        check(slide)


def template():
    return {'gates': dict.fromkeys(GATES), 'first_glance_observation': '',
            'competing_elements': [], 'evidence': []}


def review(slide, result):
    if not check(slide):
        return True
    r = result.get('attention_review')
    if not isinstance(r, dict):
        raise ValueError('attention_review required')
    gates = r.get('gates', {})
    if not isinstance(gates, dict) or any(type(gates.get(k)) is not bool for k in GATES):
        raise ValueError('Explicit attention gates required')
    text(r.get('first_glance_observation'), 'first_glance_observation')
    strings(r.get('competing_elements'), 'competing_elements', nonempty=False)
    strings(r.get('evidence'), 'attention_review.evidence')
    return all(gates[k] for k in GATES)
