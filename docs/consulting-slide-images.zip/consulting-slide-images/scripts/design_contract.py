"""Validate recorded design decisions, not their semantic or visual correctness."""
import hashlib
import json
from pathlib import Path


def text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError('Design decision needs ' + name)


def strings(value, name, nonempty=True):
    if not isinstance(value, list) or (nonempty and not value):
        raise ValueError('Design decision needs list: ' + name)
    for item in value:
        text(item, name)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def contract(brief):
    slides = []
    for slide in brief['slides']:
        objective = slide.get('objective', {})
        for key in ['page_role', 'reader_outcome', 'thesis']:
            text(objective.get(key), 'objective.' + key)
        for key in ['required_arguments', 'out_of_scope']:
            strings(objective.get(key), 'objective.' + key)
        revision = slide.get('revision', {})
        if revision.get('mode') not in ['new', 'revise']:
            raise ValueError('revision.mode must be new or revise')
        frozen_revision = dict(revision)
        if revision['mode'] == 'revise':
            for key in ['preserve', 'change']:
                strings(revision.get(key), 'revision.' + key)
            path = Path(revision.get('baseline_image', ''))
            if not path.is_absolute() or not path.is_file():
                raise ValueError('Existing absolute baseline_image required')
            frozen_revision['baseline_sha256'] = sha(path)
        slides.append({'id': slide['id'], 'objective': objective, 'revision': frozen_revision})
    return {'audience': brief['audience'], 'purpose': brief['purpose'], 'slides': slides}


def lock(run, brief, reason=None):
    data = contract(brief)
    folder = run / 'purpose-locks'
    previous = sorted(folder.glob('*.json')) if folder.exists() else []
    if previous:
        old = json.loads(previous[-1].read_text())
        if old['contract'] == data:
            return previous[-1]
        text(reason, 'reason for changing locked purpose')
    folder.mkdir(exist_ok=True)
    dest = folder / f'{len(previous)+1:03d}.json'
    dest.write_text(json.dumps({'contract': data, 'change_reason': reason,
                               'previous_sha256': sha(previous[-1]) if previous else None},
                              ensure_ascii=False, indent=2) + '\n')
    return dest


def check(run, brief):
    files = sorted((run / 'purpose-locks').glob('*.json'))
    if not files:
        raise ValueError('Run lock-purpose before reference selection/build')
    data = json.loads(files[-1].read_text())
    if data['contract'] != contract(brief):
        raise ValueError('Purpose or baseline changed; lock-purpose --reason is required')
    for slide in brief['slides']:
        check_quality_design(slide)
        use = slide.get('knowledge_use')
        if not isinstance(use, dict):
            raise ValueError('knowledge_use is required for new builds')
        for ref in use.get('references', []):
            fit = ref.get('purpose_fit', {})
            for key in ['reader_task', 'relationship', 'detail_level', 'helps_understand']:
                text(fit.get(key), 'reference purpose_fit.' + key)
            if fit.get('suitable') is not True:
                raise ValueError('Unsuitable reference cannot be selected, regardless of score')
    return files[-1]


def review(slide, result):
    purpose = result.get('purpose_review', {})
    for key in ['outcome_met', 'arguments_preserved', 'scope_respected']:
        if type(purpose.get(key)) is not bool:
            raise ValueError('purpose_review requires explicit ' + key)
    strings(purpose.get('evidence'), 'purpose_review.evidence')
    accepted = all(purpose[k] for k in ['outcome_met', 'arguments_preserved', 'scope_respected'])
    if 'quality_design' in slide:
        check_quality_design(slide)
        quality = result.get('quality_review', {})
        keys = ['content_sufficient', 'reading_path_clear', 'structure_simple', 'decoration_supportive']
        if slide['quality_design'].get('version') == 2:
            keys += ['relationship_clear', 'focal_supports_message']
        for key in keys:
            if type(quality.get(key)) is not bool:
                raise ValueError('quality_review requires explicit ' + key)
        strings(quality.get('evidence'), 'quality_review.evidence')
        accepted = accepted and all(quality[key] for key in keys)
    if slide['revision']['mode'] == 'revise':
        comparison = result.get('comparison', {})
        if comparison.get('baseline_sha256') != sha(slide['revision']['baseline_image']):
            raise ValueError('Comparison must identify the locked baseline image hash')
        for key in ['improvements', 'regressions']:
            strings(comparison.get(key), 'comparison.' + key, nonempty=False)
        text(comparison.get('reason'), 'comparison.reason')
        if comparison.get('choice') not in ['candidate', 'baseline', 'neither']:
            raise ValueError('Comparison choice must be candidate, baseline or neither')
        if comparison['choice'] == 'candidate' and not comparison['improvements']:
            raise ValueError('Choosing revised candidate needs a concrete improvement')
        accepted = accepted and comparison['choice'] == 'candidate'
    return accepted


def check_quality_design(slide):
    if 'quality_design' not in slide:
        return  # Legacy runs retain compatibility.
    quality = slide['quality_design']
    if not isinstance(quality, dict) or quality.get('version') not in (1, 2):
        raise ValueError('quality_design requires version 1 or 2')
    coverage = quality.get('coverage')
    if not isinstance(coverage, list):
        raise ValueError('quality_design.coverage must be a list')
    arguments = []
    for row in coverage:
        if not isinstance(row, dict):
            raise ValueError('coverage entries must be objects')
        text(row.get('argument'), 'coverage.argument')
        text(row.get('location'), 'coverage.location')
        arguments.append(row['argument'])
    from collections import Counter
    if Counter(arguments) != Counter(slide['objective']['required_arguments']):
        raise ValueError('Coverage must match every required argument exactly once')
    strings(quality.get('reading_path'), 'quality_design.reading_path')
    for key in ['structure_rationale', 'decoration_roles', 'density_tradeoff', 'focal_expression']:
        text(quality.get(key), 'quality_design.' + key)

    if quality['version'] == 2:
        for key in ['information_relationship', 'focal_fit_rationale']:
            text(quality.get(key), 'quality_design.' + key)
