"""Validate deck structure decisions (V4); cannot judge whether the story really reads well."""
from design_contract import text, strings

INTAKE = ('deck_size', 'audience', 'audience_state', 'usage', 'decision',
          'setting', 'key_message', 'expected_questions')
PROVENANCE = ('from_request', 'inferred', 'asked_user', 'assumed')
CERTAINTY = ('fact', 'perception', 'proposal', 'hypothesis')
HANDLING = ('main', 'appendix', 'verbal', 'open')
GATES = ('intake_confirmed', 'headlines_read_as_story', 'questions_resolved',
         'ask_on_solid_ground', 'motif_consistent')


def required(brief):
    return type(brief.get('skill_version')) is int and brief['skill_version'] >= 4


def objects(value, name, minimum=1):
    if not isinstance(value, list) or len(value) < minimum or any(not isinstance(x, dict) for x in value):
        raise ValueError(f'{name} needs at least {minimum} object(s)')
    return value


def check(brief, need=False):
    if 'deck_design' not in brief:
        if need:
            raise ValueError('skill_version 4 requires deck_design')
        return None
    d = brief['deck_design']
    if not isinstance(d, dict) or type(d.get('version')) is not int or d['version'] != 1:
        raise ValueError('deck_design requires version 1')
    ids = [s['id'] for s in brief['slides']]

    intake = d.get('intake')
    if not isinstance(intake, dict):
        raise ValueError('deck_design.intake required')
    for key in INTAKE:
        row = intake.get(key)
        if not isinstance(row, dict):
            raise ValueError('intake.' + key + ' required')
        text(row.get('value'), 'intake.' + key + '.value')
        if row.get('provenance') not in PROVENANCE:
            raise ValueError('intake.' + key + ' needs provenance: ' + '/'.join(PROVENANCE))
    if intake['deck_size']['value'] not in ('single', 'multi'):
        raise ValueError('intake.deck_size must be single or multi')
    if intake['deck_size']['value'] == 'single' and len(ids) != 1:
        raise ValueError('intake.deck_size single needs exactly one slide')
    if intake['deck_size']['value'] == 'multi' and len(ids) == 1:
        text(d.get('partial_scope'), 'partial_scope (multi-page deck built one page at a time)')

    alts = objects(d.get('alternatives'), 'alternatives', 2 if len(ids) > 1 else 1)
    alt_ids = []
    for alt in alts:
        for key in ('id', 'summary', 'conclusion_position', 'pros', 'cons'):
            text(alt.get(key), 'alternative.' + key)
        strings(alt.get('pages'), 'alternative.pages')
        alt_ids.append(alt['id'])
    if len(set(alt_ids)) != len(alt_ids):
        raise ValueError('alternative ids must be unique')
    if d.get('chosen') not in alt_ids:
        raise ValueError('chosen must name one of the alternatives')
    text(d.get('choice_reason'), 'choice_reason')

    chain = objects(d.get('headline_chain'), 'headline_chain')
    if [row.get('slide_id') for row in chain] != ids:
        raise ValueError('headline_chain must follow every slide in order')
    titles = {s['id']: s['title'] for s in brief['slides']}
    for row in chain:
        if row.get('headline') != titles[row['slide_id']]:
            raise ValueError(f"headline_chain {row['slide_id']}: headline must equal the slide title")
        for key in ('receives', 'hands_off'):
            text(row.get(key), 'headline_chain.' + key)

    for row in objects(d.get('question_ledger'), 'question_ledger', 0):
        text(row.get('question'), 'question_ledger.question')
        raised, answered = row.get('raised_on'), row.get('answered_on')
        if raised not in ids:
            raise ValueError('question_ledger.raised_on must be a slide id')
        if answered not in ids:
            raise ValueError('Unresolved question: ' + row['question'])
        if ids.index(answered) < ids.index(raised):
            raise ValueError('Question answered before it is raised: ' + row['question'])

    certainty = d.get('slide_certainty')
    if not isinstance(certainty, dict) or sorted(certainty) != sorted(str(i) for i in ids):
        raise ValueError('slide_certainty must cover every slide')
    if any(v not in CERTAINTY for v in certainty.values()):
        raise ValueError('slide_certainty values: ' + '/'.join(CERTAINTY))
    ask = d.get('ask')
    if not isinstance(ask, dict) or ask.get('slide_id') not in ids:
        raise ValueError('ask.slide_id must be a slide id')
    text(ask.get('request'), 'ask.request')
    basis = ask.get('basis')
    if not isinstance(basis, list) or not basis or any(b not in ids for b in basis):
        raise ValueError('ask.basis must list slide ids')
    if all(certainty[str(b)] == 'hypothesis' for b in basis):
        raise ValueError('The ask must not rest only on hypothesis slides')

    warnings = []
    for row in objects(d.get('anticipated_questions'), 'anticipated_questions'):
        text(row.get('question'), 'anticipated_questions.question')
        if row.get('handling') not in HANDLING:
            raise ValueError('anticipated_questions.handling: ' + '/'.join(HANDLING))
        if row['handling'] == 'main' and row.get('slide_id') not in ids:
            raise ValueError('main handling needs slide_id')
        if row['handling'] == 'open':
            warnings.append('未対応の想定質問: ' + row['question'])

    motif = d.get('motif')
    if not isinstance(motif, dict):
        raise ValueError('deck_design.motif required')
    strings(motif.get('elements'), 'motif.elements')
    text(motif.get('meaning'), 'motif.meaning')

    warnings += ['仮置きの前提: ' + k for k in INTAKE if intake[k]['provenance'] == 'assumed']
    return warnings


def validate(brief):
    return check(brief, required(brief)) or []


def template():
    return {'reviewer': '', 'headlines_only_read': '', 'gates': dict.fromkeys(GATES),
            'evidence': [], 'fixes': []}


def review(brief, result):
    if check(brief, required(brief)) is None:
        raise ValueError('deck_design required for a deck review')
    text(result.get('reviewer'), 'reviewer')
    text(result.get('headlines_only_read'), 'headlines_only_read')
    gates = result.get('gates', {})
    if not isinstance(gates, dict) or any(type(gates.get(k)) is not bool for k in GATES):
        raise ValueError('Explicit deck gates required')
    strings(result.get('evidence'), 'deck_review.evidence')
    passed = all(gates[k] for k in GATES)
    if not passed:
        strings(result.get('fixes'), 'deck_review.fixes')
    return passed
