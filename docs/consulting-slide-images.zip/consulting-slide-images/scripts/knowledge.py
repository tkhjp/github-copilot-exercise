"""Read-only live ratings + AI annotations. No API, writes only derived index."""
import json, os
from pathlib import Path
SAMPLES = Path(__file__).resolve().parents[1]/'assets/samples'
DEFAULT_LIBRARY = Path(os.environ.get('SLIDE_LIBRARY', Path.home()/'Desktop/資料見本ライブラリ'))
def load(path=DEFAULT_LIBRARY):
 p=Path(path).expanduser();catalog=json.loads((p/'catalog.json').read_text());baseline=json.loads((p/'baseline-reviews.json').read_text());reviews=json.loads((p/'reviews/ratings.json').read_text());labels_path=p/'knowledge-labels.json'
 labels=json.loads(labels_path.read_text()).get('items',{}) if labels_path.exists() else {}
 rows=[]
 for item in catalog:
  base=baseline['items'].get(item['id'],{});r=reviews['ratings'].get(item['path'],{});scores=r.get('criteria',base.get('scores'))
  if not r.get('eligible',base.get('eligible',False)) or r.get('reviewed') is not True:continue
  if not isinstance(scores,list) or len(scores)!=6 or any(type(n)!=int or not 1<=n<=5 for n in scores):continue
  row={k:item.get(k) for k in ['id','name','deck','slide','origin','path','text']}
  src=item.get('src','');row.update(image=str(p/src) if not src.startswith('render/') else None,image_url='http://127.0.0.1:18769/'+src,original=str(p/item['original']) if item.get('original') else None)
  row.update(scores=scores,aggregate=round(sum(scores)/6,2),score_source='user_confirmed_adjusted' if scores!=base.get('scores') else 'user_confirmed_baseline',review_updated_at=r.get('updatedAt'),user_memo=r.get('memo',''),ai_initial_observation=base.get('note',''),ai_initial_tags=base.get('tags',[]),render_caveat=base.get('renderCaveat',False),labels=labels.get(item['id']),label_status='ai_interpretation' if item['id'] in labels else 'needs_visual_labeling')
  rows.append(row)
 return {'version':1,'library':str(p),'ratings_saved_at':reviews.get('savedAt'),'rubric':baseline['rubric'],'policy':'Open reference set, not exhaustive templates. Relevance first; consider six scores and user memo. Excluded and unconfirmed omitted. AI labels are interpretations, not user statements.','items':rows}
def search(index,query):
 terms=query.lower().split()
 def hits(x):
  t=json.dumps({k:x.get(k) for k in ['name','text','labels','ai_initial_tags','ai_initial_observation','user_memo']},ensure_ascii=False).lower()
  return sum(term in t for term in terms)
 rows=[dict(x,query_matches=hits(x)) for x in index['items']]
 if terms:rows=[x for x in rows if x['query_matches']]
 return sorted(rows,key=lambda x:(-x['query_matches'],-x['aggregate'],x['id']))
def load_samples(root=SAMPLES):
 """Bundled sample decks (PDF + page images + notes). Not user-scored; notes are AI interpretation."""
 idx=Path(root)/'samples.json'
 if not idx.exists(): return {'decks':[],'items':[]}
 data=json.loads(idx.read_text(encoding='utf-8'));items=[]
 for d in data['decks']:
  d['pdf_path']=str(Path(root)/d['pdf']) if d.get('pdf') else None
  for pg in d['pages']:
   items.append(dict(pg,deck=d['id'],deck_title=d['title'],image=str(Path(root)/pg['image']),pdf=d['pdf_path'],scores=None,aggregate=None,score_source='bundled_sample',label_status='ai_interpretation'))
 return {'decks':data['decks'],'items':items}
def search_samples(samples,query):
 terms=query.lower().split()
 def hits(x):
  t=json.dumps({k:x.get(k) for k in ['deck_title','message','relationship','expression','adopt']},ensure_ascii=False).lower()
  return sum(term in t for term in terms)
 rows=[dict(x,query_matches=hits(x)) for x in samples['items']]
 if terms:rows=[x for x in rows if x['query_matches']]
 return sorted(rows,key=lambda x:(-x['query_matches'],x['id']))
