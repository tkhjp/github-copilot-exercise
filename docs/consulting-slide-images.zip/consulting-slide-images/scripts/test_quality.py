import copy,unittest
import design_contract as d
class QualityTests(unittest.TestCase):
 def setUp(self):
  self.s={'objective':{'required_arguments':['why','how']},'revision':{'mode':'new'},'quality_design':{'version':1,'coverage':[{'argument':'why','location':'cause diagram'},{'argument':'how','location':'explanation'}],'reading_path':['cause','action'],'structure_rationale':'causal relation','decoration_roles':'color distinguishes change','density_tradeoff':'keep mechanism, remove duplicate title','focal_expression':'joined boundary depicts restored continuity'}}
  self.r={'purpose_review':{'outcome_met':True,'arguments_preserved':True,'scope_respected':True,'evidence':['observed']},'quality_review':{'content_sufficient':True,'reading_path_clear':True,'structure_simple':True,'decoration_supportive':True,'evidence':['observed entry and support']}}
 def test_coverage_omission_and_duplicate_rejected(self):
  for rows in [self.s['quality_design']['coverage'][:1],[self.s['quality_design']['coverage'][0]]*2]:
   s=copy.deepcopy(self.s);s['quality_design']['coverage']=rows
   with self.assertRaises(ValueError):d.check_quality_design(s)
 def test_missing_review_rejected(self):
  del self.r['quality_review']
  with self.assertRaises(ValueError):d.review(self.s,self.r)
 def test_negative_quality_overrides_purpose_pass(self):
  self.assertTrue(d.review(self.s,self.r));self.r['quality_review']['content_sufficient']=False;self.assertFalse(d.review(self.s,self.r))
 def test_legacy_compatible(self):
  del self.s['quality_design'];del self.r['quality_review'];self.assertTrue(d.review(self.s,self.r))
if __name__=='__main__':unittest.main()

class FitTests(QualityTests):
 def setUp(self):
  super().setUp()
  self.s['quality_design'].update(version=2,information_relationship='cause and response',focal_fit_rationale='joined boundary makes continuity visible')
  self.r['quality_review'].update(relationship_clear=True,focal_supports_message=True)
 def test_v2_missing_fit_rejected(self):
  del self.s['quality_design']['information_relationship']
  with self.assertRaises(ValueError):d.check_quality_design(self.s)
 def test_v2_bad_focal_overrides_other_pass(self):
  self.assertTrue(d.review(self.s,self.r))
  self.r['quality_review']['focal_supports_message']=False
  self.assertFalse(d.review(self.s,self.r))
 def test_v2_missing_fit_review_rejected(self):
  del self.r['quality_review']['relationship_clear']
  with self.assertRaises(ValueError):d.review(self.s,self.r)
