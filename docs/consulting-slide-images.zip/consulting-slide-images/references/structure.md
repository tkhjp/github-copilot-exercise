# 資料構成（V4）

2026-10-08のユーザー明示：資料構成を検討する段階をスキルに入れる。あわせて「資料1枚か複数枚か、聞き手は誰か、用途は何か、なども初期に質問としてユーザーにすべき」。ページの設計（purpose・glance）より前に、資料全体の構成を決める。

## 1. 聞き取りは別スキル

聞き取りは **document-intake スキル**が担う（2026-10-08 ユーザー明示：「資料作成のスキルと一緒にせず」）。このスキルでは聞き取りをしない。

- 案件フォルダに `intake.json` があれば読み、8項目（deck_size／audience／audience_state／usage／decision／setting／key_message／expected_questions）を値と出所ごと deck_design.intake へ写す。
- なければ、ページの設計に入る前に document-intake スキルを起動して聞き取りを済ませる。会話や骨子で全項目が埋まる場合も、同スキルの手順で intake.json に残してから進む。
- 仮置き（assumed）の項目は、資料の完成時に未確認として返す。
- 構成案を出すときは、冒頭に「前提（推測を含む）」として intake の要点を短く並べ、推測（inferred）と仮置き（assumed）が分かるようにする。ユーザーはそこで前提を直す（ユーザー明示：あまり多くの質問をしない）。

## 2. 構成の判断基準

1. **決めてほしいことから逆算する。** どのページも判断にどう効くかが言える。言えないページは削るか付録へ。
2. **見出しだけ読んで話が通じる。** 各ページのタイトルを順に読むと一つの話になる。前ページから受け取るもの・次へ渡すものが一文で書ける。
3. **読み手の現在地から始める。** 既知・合意済みは短く。まだ持っていないもの（全体感、実例、選択肢など）に紙面を使う。
4. **出した問いは後のページで必ず回収する。** 問いを出したページと答えるページを対応させ、答える側に「Q1に答える」等の印を付ける。
5. **確かなものから順に並べ、お願いは確かな根拠の上に置く。** 事実→認識→提案→仮説。お願い（Go）は仮説だけを根拠にしない。小さく確実な一歩を承認対象にし、大きな絵は仮説として示す。
6. **抜けている論点は作る前に洗い出す。** 想定質問を構成段階で挙げ、本編・付録・口頭のどれで扱うか決める。
7. **結論の位置と通しの図形を意図して決める。** 結論先出し（エグゼクティブ・送付向き）と積み上げ（全体像の共有が先に要る場合）を比べて選ぶ。色や図形の意味（例：紫＝AI、紺＝SI）をページをまたいで固定し、一つの話に見せる。

## 3. 記録（brief.deck_design version 1）

brief.skill_version=4 で必須。

- intake：document-intake の intake.json から写した8項目。各 `{value, provenance}`。provenance は from_request／asked_user／assumed。deck_size は single か multi で、ページ数と一致させる。
- alternatives：構成案。複数枚なら2案以上（1枚なら1案以上）。各 `{id, summary, conclusion_position, pages[], pros, cons}`。
- chosen・choice_reason：選んだ案と理由（読み手・用途・決めてほしいことに結び付けて書く）。
- headline_chain：全ページを順に `{slide_id, headline, receives, hands_off}`。headline はスライドの title と完全一致。
- question_ledger：`{question, raised_on, answered_on}`。答えるページが問いのページより後にあること。回収しない問いは置かない。
- slide_certainty：各ページの確からしさ（fact／perception／proposal／hypothesis）。
- ask：`{slide_id, request, basis[]}`。basis が仮説ページだけになってはならない。
- anticipated_questions：`{question, handling, slide_id?}`。handling は main（slide_id 必須）／appendix／verbal／open。open は警告として残す。
- motif：`{elements[], meaning}`。ページをまたいで使う色・図形とその意味。

## 4. 構成レビュー

1. ページを描く前に、brief の見出しだけを読んで `review-deck` を行う。
2. 全ページを描き終えたら、実画像の見出しを読んで再度 `review-deck` を行う（brief を変えると前回は stale になる）。

記録項目：headlines_only_read（見出しだけ読んで受け取った話の筋）、gates（intake_confirmed／headlines_read_as_story／questions_resolved／ask_on_solid_ground／motif_consistent）、evidence、false がある場合は fixes。false があれば、ページの描き直しより先に構成を直す。

機械検査は記録の整合性（見出しと題の一致、問いの回収、お願いの根拠、聞き取りの出所）だけを見る。話として通じるかの判断は、見出しを実際に読んだエージェントが正直に行う。
