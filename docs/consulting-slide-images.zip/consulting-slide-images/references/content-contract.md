# 内容・全体構成・指示の追跡

新規制作ではbriefにcontent_contract.version=1を記録する。従来のquality_design version 2は併用する。目的を先に固定し、内容検証を経て構造とアイキャッチを設計する。既存の保存版とcontent_contractなしの旧案件は互換を維持する。

## 設計記録
- sources: [{id, locator, evidence, verification}]。locatorは原稿・資料の具体的な位置、evidenceは該当内容。verificationはuser_provided / verified / unverified。ユーザー提供の構想は、実装済みの外部検証を意味しない。
- storyline: [{slide_id, role, incoming, outgoing}]。全ページを順に一度ずつ対応。incoming/outgoingは前後の論点への接続。単独ページは導入と読後の到達点を書く。用語・数値・前提のページ間矛盾を目視で確認。
- arguments: [{id, slide_id, claim, source_ids, warrant, qualification}]。主要な主張を根拠と結び、warrantに根拠から結論へ至る理由、qualificationに提案・推論・成立条件・限界を記録する。原稿を出典にするだけで実装済みとしない。未確認の断定は弱めるか、必要な確認を明記する。
- instructions: [{id, text, slide_ids, locations, disposition, reason}]。反映箇所を記録。dispositionはapplied / superseded / not_applicable。変更指示や適用外の理由が必要で、未対応を勝手に適用外としない。
- role_checks: [{id, slide_id, topic, applicable, reason, details}]。役割に応じた確認。計画なら担当・時期・移行条件、効果検証なら指標・比較・基準、構想なら仕組み・成立条件・責任境界など。applicable=falseは理由を残す。未確定の氏名・日付・数値は創作せず決定事項にする。背景ページに無理にアクションを足さない。

## 提出前の内容レビュー
content_reviewはreview-templateで未判定の枠を作る。全ページを確認してから記入する。
- gates: truthfulness / reasoning / audience_fit / cross_page_consistency / instructions_followed / release_ready のboolean。
- arguments: [{id, supported, evidence}]。全argumentsを一度ずつ評価。画像の表現と原資料を照合する。
- instructions: [{id, satisfied, evidence}]。全指示について実成果物上の反映を確認。
- role_checks: [{id, met, evidence}]。適用した確認項目だけを評価。
- observations: 具体的な観察の配列。

falseは描画点数と無関係にrevise。重大な真実性・指示の問題、論理、理解・判断、視覚表現の順に直す。提出確認は実際に渡すファイルを対象とし、作業用メモ・他案件情報・意図しない個人情報の残存を調べる。PPTのノート・非表示情報などは該当形式を制作した場合に確認する。

機械検査は必須記録、ID参照、全ページ・指示の網羅、明示判定の整合性を調べる。引用内容の真偽、論理、語彙の適合、見やすさはエージェントの照合・目視判断であり、自動採点ではない。項目数や文字数を品質とみなさず、意味の重複と空疎な表現を削り、必要な説明は保つ。

内容検証の結果をすべて図示する必要はない。独立した表示領域を増やす前に、既存のリード・工程説明・注記へ自然に統合できるかを検討する。視線設計はattention.mdを参照。
