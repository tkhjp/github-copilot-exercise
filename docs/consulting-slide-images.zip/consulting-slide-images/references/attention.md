# 初見の視線設計

内容の厳密さと見せる要素数を切り離す。根拠・指示・責任境界の確認は制作記録で行い、理解に必要な結果だけを表示する。チェック項目ごとに箱・対比・矢印を増やさない。

新規・改訂の各slideにattention_design.version=1を追加：
- entry_point：初見で最初に捉えてほしい箇所。
- primary_focus：本文領域で主役となるまとまりと伝える意味。
- secondary_elements：補足となる領域の配列。
- hierarchy_strategy：面積・配置・色・太さ・余白で主従をどう作るか。
- internal_only_checks：確認はするが専用の表示領域を設けない事項の配列。

生成後、先に画像全体を見てattention_reviewを記録し、その後で細部を読む。first_glance_observationに実際に最初に目へ入った箇所、competing_elementsに競合した要素（なければ空配列）、evidenceに具体的な画像観察を記録。gatesはentry_clear / primary_dominant / secondary_subordinateのboolean。falseならrevise。正しい読む順序を説明できることだけでは初見の分かりやすさを合格にしない。機械は目線を計測せず、判定記録の欠落・整合性だけを検査する。

これは全資料を一つの図に限定するルールではない。比較が主張なら複数パネル自体が主役になり得る。循環や紫の使用数を固定せず、必要な具体情報を削って見かけだけ簡単にしない。改訂はユーザーが評価した前版のまとまりを保存し、必要な変更へ絞る。
