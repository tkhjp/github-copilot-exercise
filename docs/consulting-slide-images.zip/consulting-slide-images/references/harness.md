# ローカル制作ハーネス

Python 3標準ライブラリのみ。画像生成の実行はChatGPT（またはCodex）でユーザーが行い、生成画像を `<run>/inbox/` に置く。内容検査は画像を見たエージェントが担う。自動OCR・自動美的評価・無人生成サービスではない。

以下の `<skill>` はこのスキルの絶対パス、`<run>` は案件フォルダへ置換する。

```sh
python3 <skill>/scripts/harness.py samples --query "循環 役割"        # 同梱の見本デッキ（常に使える）
python3 <skill>/scripts/harness.py knowledge --query "循環 改善" --limit 8
python3 <skill>/scripts/harness.py init <run>
python3 <skill>/scripts/harness.py lock-purpose <run>
python3 <skill>/scripts/harness.py build <run>
python3 <skill>/scripts/harness.py review-template <run>/review.json
python3 <skill>/scripts/harness.py record <run> --slide 1 --image /absolute/generated.png --review <run>/review.json --prompt <run>/builds/001/slide-01.txt
# コード描画のときは --image <run>/render/slide-01.png --prompt <run>/render/slide-01.html
python3 <skill>/scripts/harness.py deck-review-template <run>/deck-review.json
python3 <skill>/scripts/harness.py review-deck <run> --review <run>/deck-review.json
python3 <skill>/scripts/harness.py status <run>
```

1. initはSECOM人材循環の記入例を作る。必ず依頼内容に置き換える。
2. [目的の固定と比較](purpose.md)に従いobjective・revisionを記録し、参照選択前にlock-purposeする。変更時は理由を保存する。参照にはpurpose_fitが必須。brief.jsonの各ページでtitle、takeaway、layout、任意のreference、knowledge_use、blocks、diagram、claimsを指定。blocksはheadingとbody。diagram.nodesはid・label・detail、edgesはfrom・to・label。claimsはtext・status・source。statusはfact／proposal／perception。根拠の存在だけを機械検査し、その内容はエージェントが照合する。
3. buildは入力の必須項目、図の接続先、根拠の記載を検証して版別プロンプトを作る。manifest内の参照画像を閲覧してから生成ツールへ渡す。修正時に追加指示を付けたら、実際に渡した全文を別ファイルに保存しrecordへ指定する。
4. review-templateは未判定(null)を作る。画像を見て埋める。未判定はrecordが拒否する。inboxに置かれた生成画像のパスを使い、既存の見本を生成結果として登録しない。
5. recordは画像・プロンプト・brief・レビューをv01、v02…として保存し、基準からpass／reviseを計算する。元画像を変更しない。担当エージェントの採点が正しいことまで保証しない。
6. statusは各ページの最新レビューを返す。briefを変更した後のレビューはstale_brief、保存画像が変わったらimage_changed。再確認するまで完成と呼ばない。

保存物：brief.json／builds（版別入力・プロンプト）／slide-NN/vNN（画像・実使用プロンプト・レビュー）。案件フォルダを渡せば別セッションから再開できる。スキル自身の中に案件結果を保存しない。

## ナレッジを利用した制作

参照元は2つ。①同梱の見本デッキ（`assets/samples/`、samplesコマンド。ページIDは `<deck>-pNN`）。ユーザー採点はなく、索引のノートはAIの解釈。buildでは score_source=bundled_sample として記録する。②資料見本ライブラリ（任意、knowledgeコマンド、6観点のユーザー採点つき）。references に同梱見本のIDだけを書く場合、ライブラリは不要。

見本デッキを追加・更新するときは `assets/samples/<deck>/deck.pdf` を置き、`scripts/pdf_pages.swift` でページ画像を書き出し、samples.json と INDEX.md に全ページのノートを追記する（ページ画像を見て書く）。ページ画像を書き出した後、PDFは置いたままでも削除してもよい。

[参照方針・ラベル仕様](knowledge.md)に従う。knowledgeは最新の確定評価を読む。--libraryで場所を変更、--outputで派生インデックスを保存できる。ユーザー評価・原資料は変更しない。検索は語句一致で、該当なしでも独自設計で進める。

buildはknowledge_useの参照IDを最新の評価と照合し、6観点・平均・評価の出所・ラベル・設計判断を版別knowledge-snapshot.jsonに保存する。対象外・未確認のIDは拒否する。独自設計ならmode=original、references=[]でよく、reference画像も不要。既存briefは互換性のためknowledge_use未記載を警告する。新規作成では記入する。固定の223枚や同梱4画像からの選択に制限しない。生成品質の0〜2点レビューと、参照資料のユーザー6観点1〜5点評価は別の尺度として扱う。

目的の記録・適合理由・改訂比較の欠落はbuild/recordで拒否する。目的レビューがfalse、または比較でbaseline/neitherを選ぶ場合は、描画点数が高くてもrevise。既存の保存版は書き換えない。

新規制作ではpreferences.mdのquality_designを記録する。buildは必須論拠と配置の対応を検証し、recordはquality_reviewの4判定と具体的証拠を要求する。falseがあれば描画スコアが高くてもrevise。既存案件は互換を保持する。

新規制作はpreferences.mdのquality_design version 2を使用。情報の関係・構造の適合理由・アイキャッチの適合理由を記録し、review-templateのrelationship_clear / focal_supports_messageを目視で判定する。version 1の保存版は変更不要。

新規制作のcontent_contract version 1は[内容検証仕様](content-contract.md)に従う。buildで出典参照・全ページ構成・指示反映先を検証し、recordでcontent_reviewを要求する。未判定・レビュー漏れを拒否し、falseならrevise。旧briefは互換維持。

V2では[初見の視線設計](attention.md)を追加。attention_design version 1をbuildで検証し、recordでattention_reviewの3判定と初見の観察を要求する。falseはrevise。既存保存版は互換維持。

V3（Claude版）では brief に `skill_version: 3` を記録し、各slideに[一目で伝わる構造](glance.md)の glance_design version 1 を必須にする。buildで検証し、recordで glance_review の3判定・本文を読まずに受け取った一文・残した具体情報を要求する。falseはrevise。skill_version 未記載の旧案件は互換維持。描画は[コード描画](render.md)が既定。


V4（2026-10-08）では brief に `skill_version: 4` を記録し、[資料構成](structure.md)の deck_design version 1 を必須にする。build は聞き取りの出所、構成案の比較、見出しとタイトルの一致、問いの回収、お願いの根拠を検証し、仮置きの前提と未対応の想定質問を警告に出す。`review-deck` は資料全体の構成レビューを `<run>/deck/vNN` に保存する。status は先頭に資料構成の状態（not_reviewed／pass／revise／stale_brief）を返す。構成が pass かつ最新でなければ完成と呼ばない。skill_version 3 以前の案件は互換維持。
