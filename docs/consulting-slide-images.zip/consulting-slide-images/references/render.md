# コード描画で資料画像を作る（Claude版）

Claude は画像生成ができない。既定は HTML/CSS/SVG で組み、Microsoft Edge のヘッドレス機能で PNG に書き出す。日本語が崩れず、部分修正が確実。ChatGPT／Codex での画像生成は、ユーザーが望むときの選択肢。

## 書き出し

```sh
"/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" --headless=new --disable-gpu --hide-scrollbars \
  --force-device-scale-factor=2 --window-size=1920,1080 \
  --screenshot="<run>/render/slide-NN.png" "file://<run>/render/slide-NN.html"
```

3840×2160 で出る。書き出した PNG は Read で必ず目視する。

## HTML の約束

- 1920×1080 固定、白地、`overflow:hidden`。フォントは Hiragino Sans。
- `word-break: auto-phrase` を body に付け、日本語の不自然な改行を防ぐ。
- 色は CSS 変数（白・黒・紫 #A100FF が既定）。外部ファイルや外部CDNに依存しない。
- アイコンはインライン SVG で、意味を伝える場合に使う。主構造（glance_structure）を最大の面積・最も強いコントラストで描く。
- **本文の文字を小さくしすぎない**（2026-10-07 ユーザー明示）。1920×1080 基準で、本文・ノードの説明・矢印ラベルは 16px 以上、注記・出典だけ 14px まで。収まらないときは文字を縮めず、重複の削除・言い回しの短縮・箱の拡大・ページ分割で解決する。タイトルや見出しは通常小さくならないが、本文との差を保つ。
- 矢印は SVG の marker で描き、向き・実線/破線で意味を区別する。

## 文字サイズの自動チェック（必須）

PNG を書き出したら、record の前に必ず実行する。

```sh
python3 <skill>/scripts/check_text_size.py <run>/render/slide-NN.html
```

- 実際に描画して、すべての可視テキスト（SVG の `<text>`、バッジ、表の小見出し、凡例、ラベルを含む）の文字サイズを測る。
- 基準は本文 16px 以上。class に `note` / `foot` / `src` を含む注記・出典だけ 14px まで。
- NG が出たら必ず直してから record する。バッジ・小見出し・図のラベルも例外にしない（2026-10-07 ユーザー指摘）。
- 画像に焼き込まれた文字（生成画像・スクリーンショット）は測れない。目視で読めるか確認し、小さければ observations に書く。

## 記録

`record --image <run>/render/slide-NN.png --prompt <run>/render/slide-NN.html`。描画ソースのHTMLを「実際に使った生成指示」として保存する。修正のたびに PNG を書き出し直し、版として record する。
