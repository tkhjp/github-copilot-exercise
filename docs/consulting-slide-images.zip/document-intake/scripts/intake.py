#!/usr/bin/env python3
"""Document intake records: template, structural check, markdown summary. No semantic judgement."""
import json
import sys
from pathlib import Path

FIELDS = {
    'deck_size': '枚数', 'audience': '聞き手', 'audience_state': '聞き手の現在地',
    'usage': '用途', 'decision': '決めてほしいこと', 'setting': '時間・場',
    'key_message': '伝えたい一文', 'expected_questions': '想定される質問'}
PROVENANCE = {'from_request': '依頼・資料から', 'inferred': '推測', 'asked_user': '聞き取り', 'assumed': '仮置き'}


def template():
    return {'version': 1, 'title': '', 'deck_size_detail': '',
            'fields': {k: {'value': '', 'provenance': None, 'note': ''} for k in FIELDS},
            'extras': {}}


def check(data):
    if not isinstance(data, dict) or data.get('version') != 1:
        raise ValueError('intake version 1 required')
    if not isinstance(data.get('title'), str) or not data['title'].strip():
        raise ValueError('title required')
    fields = data.get('fields')
    if not isinstance(fields, dict):
        raise ValueError('fields required')
    for key in FIELDS:
        row = fields.get(key)
        if not isinstance(row, dict) or not isinstance(row.get('value'), str) or not row['value'].strip():
            raise ValueError('missing value: ' + key)
        if row.get('provenance') not in PROVENANCE:
            raise ValueError('provenance for ' + key + ' must be one of ' + '/'.join(PROVENANCE))
        if row['provenance'] in ('assumed', 'inferred') and not str(row.get('note', '')).strip():
            raise ValueError(row['provenance'] + ' ' + key + ' needs a note with the basis or reason')
    if fields['deck_size']['value'] not in ('single', 'multi'):
        raise ValueError('deck_size value must be single or multi')
    if not isinstance(data.get('extras', {}), dict):
        raise ValueError('extras must be an object')
    return [k for k in FIELDS if fields[k]['provenance'] == 'assumed']


def markdown(data):
    assumed = check(data)
    f = data['fields']
    size = {'single': '1枚', 'multi': '複数枚'}[f['deck_size']['value']]
    if data.get('deck_size_detail'):
        size += f"（{data['deck_size_detail']}）"
    lines = [f"# 聞き取り：{data['title']}", '', '| 項目 | 内容 | 出所 |', '|---|---|---|']
    for key, label in FIELDS.items():
        value = size if key == 'deck_size' else f[key]['value']
        note = f" ※{f[key]['note']}" if f[key].get('note') else ''
        lines.append(f"| {label} | {value}{note} | {PROVENANCE[f[key]['provenance']]} |")
    for key, value in data.get('extras', {}).items():
        lines.append(f'| {key} | {value} | 依頼・資料から |')
    inferred = [k for k in FIELDS if f[k]['provenance'] == 'inferred']
    lines += ['', '## 推測した項目（確認してほしい）', '']
    lines += [f'- {FIELDS[k]}：{f[k]["value"]}（根拠：{f[k]["note"]}）' for k in inferred] or ['- なし']
    lines += ['', '## 未確認（仮置き）', '']
    lines += [f'- {FIELDS[k]}：{f[k]["value"]}（{f[k]["note"]}）' for k in assumed] or ['- なし']
    return '\n'.join(lines) + '\n'


def main(argv):
    if len(argv) != 3 or argv[1] not in ('template', 'check', 'md'):
        print('usage: intake.py template <dir> | check <intake.json> | md <intake.json>', file=sys.stderr)
        return 2
    cmd, target = argv[1], Path(argv[2])
    if cmd == 'template':
        target.mkdir(parents=True, exist_ok=True)
        out = target / 'intake.json'
        if out.exists():
            raise ValueError('intake.json already exists; edit it instead')
        out.write_text(json.dumps(template(), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(out)
        return 0
    data = json.loads(target.read_text(encoding='utf-8'))
    if cmd == 'check':
        print(json.dumps({'ok': True, 'assumed': check(data)}, ensure_ascii=False))
        return 0
    out = target.with_name('intake.md')
    out.write_text(markdown(data), encoding='utf-8')
    print(out)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except (ValueError, OSError, json.JSONDecodeError) as e:
        print('ERROR: ' + str(e), file=sys.stderr)
        sys.exit(1)
