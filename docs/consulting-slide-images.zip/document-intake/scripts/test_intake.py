import unittest
import intake


def filled():
    d = intake.template()
    d['title'] = 'SI x AI'
    for key in intake.FIELDS:
        d['fields'][key] = {'value': 'x', 'provenance': 'from_request', 'note': ''}
    d['fields']['deck_size']['value'] = 'multi'
    return d


class IntakeTests(unittest.TestCase):
    def test_template_is_incomplete(self):
        with self.assertRaises(ValueError): intake.check(intake.template())

    def test_pass(self):
        self.assertEqual(intake.check(filled()), [])

    def test_assumed_needs_note(self):
        d = filled()
        d['fields']['usage']['provenance'] = 'assumed'
        with self.assertRaises(ValueError): intake.check(d)
        d['fields']['usage']['note'] = 'not answered; meeting projection assumed'
        self.assertEqual(intake.check(d), ['usage'])

    def test_inferred_needs_basis(self):
        d = filled()
        d['fields']['audience']['provenance'] = 'inferred'
        with self.assertRaises(ValueError): intake.check(d)
        d['fields']['audience']['note'] = 'Copilot summary targets client IT leads'
        self.assertEqual(intake.check(d), [])
        self.assertIn('推測した項目', intake.markdown(d))

    def test_deck_size_values(self):
        d = filled()
        d['fields']['deck_size']['value'] = '4'
        with self.assertRaises(ValueError): intake.check(d)

    def test_bad_provenance(self):
        d = filled()
        d['fields']['audience']['provenance'] = 'guess'
        with self.assertRaises(ValueError): intake.check(d)

    def test_markdown_lists_assumed(self):
        d = filled()
        d['fields']['setting'] = {'value': '30分', 'provenance': 'assumed', 'note': '未回答'}
        md = intake.markdown(d)
        self.assertIn('時間・場：30分', md)
        self.assertIn('| 枚数 | 複数枚 |', md)


if __name__ == '__main__':
    unittest.main()
