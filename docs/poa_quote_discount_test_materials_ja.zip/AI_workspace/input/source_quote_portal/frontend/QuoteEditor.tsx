import { useState } from "react";

type QuoteLine = {
  product_code: string;
  quantity: number;
  unit_price: number;
  discount_rate: number;
};

export function QuoteEditor({ ownerId }: { ownerId: string }) {
  const [customerName, setCustomerName] = useState("");
  const [dealName, setDealName] = useState("");
  const [validUntil, setValidUntil] = useState("");
  const [lines, setLines] = useState<QuoteLine[]>([
    { product_code: "SVC-STD", quantity: 1, unit_price: 120000, discount_rate: 0 },
  ]);
  const [message, setMessage] = useState("");

  async function saveQuote() {
    setMessage("");
    const response = await fetch("/api/quotes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer_name: customerName,
        deal_name: dealName,
        owner_id: ownerId,
        valid_until: validUntil,
        lines,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      setMessage(error.detail ?? "見積保存に失敗しました");
      return;
    }

    setMessage("見積を保存しました");
  }

  return (
    <section>
      <h1>見積作成</h1>
      <label>
        顧客名
        <input value={customerName} onChange={(event) => setCustomerName(event.target.value)} />
      </label>
      <label>
        案件名
        <input value={dealName} onChange={(event) => setDealName(event.target.value)} />
      </label>
      <label>
        見積有効期限
        <input type="date" value={validUntil} onChange={(event) => setValidUntil(event.target.value)} />
      </label>
      <button type="button" onClick={saveQuote}>保存</button>
      {message && <p>{message}</p>}
    </section>
  );
}
