export function ApprovalList() {
  return (
    <section>
      <h1>承認待ち見積</h1>
      <p>承認ワークフローは未実装です。</p>
    </section>
  );
}
