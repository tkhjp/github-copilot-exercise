from datetime import date, datetime
from enum import Enum
from pydantic import BaseModel, Field


class Role(str, Enum):
    sales = "sales"
    admin = "admin"


class QuoteStatus(str, Enum):
    draft = "draft"
    issued = "issued"
    expired = "expired"


class User(BaseModel):
    id: str
    name: str
    department_code: str
    role: Role


class Product(BaseModel):
    product_code: str
    product_name: str
    category: str
    list_price: int
    standard_cost: int


class QuoteLine(BaseModel):
    product_code: str
    quantity: int
    unit_price: int
    discount_rate: float = 0.0


class Quote(BaseModel):
    id: str
    customer_name: str
    deal_name: str
    owner_id: str
    lines: list[QuoteLine]
    valid_until: date
    status: QuoteStatus = QuoteStatus.draft
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class QuoteCreate(BaseModel):
    customer_name: str
    deal_name: str
    owner_id: str
    lines: list[QuoteLine]
    valid_until: date
