from datetime import date
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import PlainTextResponse

from models import Product, Quote, QuoteCreate, QuoteStatus, Role, User
from pricing import calculate_gross_margin_rate, calculate_quote_total, has_invalid_discount


app = FastAPI(title="Quote Portal")

users = [
    User(id="U100", name="鈴木 一郎", department_code="SALES-EAST", role=Role.sales),
    User(id="U101", name="高橋 美咲", department_code="SALES-WEST", role=Role.sales),
    User(id="U900", name="管理者", department_code="SYSTEM", role=Role.admin),
]

products = [
    Product(
        product_code="SVC-STD",
        product_name="標準サポートサービス",
        category="service",
        list_price=120000,
        standard_cost=70000,
    ),
    Product(
        product_code="LIC-CRM",
        product_name="CRMライセンス",
        category="software",
        list_price=240000,
        standard_cost=150000,
    ),
]

quotes: list[Quote] = []


@app.get("/api/quotes")
def list_quotes(owner_id: str | None = Query(default=None), status: QuoteStatus | None = Query(default=None)):
    result = quotes
    if owner_id:
        result = [quote for quote in result if quote.owner_id == owner_id]
    if status:
        result = [quote for quote in result if quote.status == status]
    return [
        {
            **quote.model_dump(),
            "total_amount": calculate_quote_total(quote),
            "gross_margin_rate": calculate_gross_margin_rate(quote, products),
        }
        for quote in result
    ]


@app.post("/api/quotes")
def create_quote(payload: QuoteCreate):
    for line in payload.lines:
        if has_invalid_discount(line):
            raise HTTPException(status_code=400, detail="値引き率が不正です")

    quote = Quote(
        id=f"Q{len(quotes) + 1:05d}",
        customer_name=payload.customer_name,
        deal_name=payload.deal_name,
        owner_id=payload.owner_id,
        lines=payload.lines,
        valid_until=payload.valid_until,
        status=QuoteStatus.draft,
    )
    quotes.append(quote)
    return quote


@app.post("/api/quotes/{quote_id}/issue")
def issue_quote(quote_id: str):
    for quote in quotes:
        if quote.id == quote_id:
            if quote.valid_until < date.today():
                raise HTTPException(status_code=400, detail="有効期限切れの見積は発行できません")
            # 現行実装では、値引き承認や粗利率による発行ブロックを行っていない。
            quote.status = QuoteStatus.issued
            return quote
    raise HTTPException(status_code=404, detail="見積が見つかりません")


@app.get("/api/export/quotes.csv", response_class=PlainTextResponse)
def export_quotes_csv():
    # 既存CSVは最低限の項目のみ。承認状態、承認者、粗利率、Shift_JISには未対応。
    lines = ["quote_id,customer_name,deal_name,owner_id,status,total_amount"]
    for quote in quotes:
        lines.append(
            ",".join(
                [
                    quote.id,
                    quote.customer_name,
                    quote.deal_name,
                    quote.owner_id,
                    quote.status,
                    str(calculate_quote_total(quote)),
                ]
            )
        )
    return "\n".join(lines)
