def notify_approval_requested(quote_id: str, approver_id: str) -> None:
    """承認依頼通知の将来拡張用スタブ。現時点では何もしない。"""
    # TODO: メール、Teams、またはポータル内通知のどれを使うか決定後に実装する。
    return None


def notify_approval_result(quote_id: str, requester_id: str, result: str) -> None:
    """承認結果通知の将来拡張用スタブ。現時点では何もしない。"""
    # TODO: 差戻しコメントと通知テンプレートが未確定。
    return None
