from models import Product, Quote, QuoteLine


def calculate_line_amount(line: QuoteLine) -> int:
    discounted_price = line.unit_price * (1 - line.discount_rate)
    return int(discounted_price * line.quantity)


def calculate_quote_total(quote: Quote) -> int:
    return sum(calculate_line_amount(line) for line in quote.lines)


def calculate_gross_margin_rate(quote: Quote, products: list[Product]) -> float | None:
    product_map = {product.product_code: product for product in products}
    total_amount = 0
    total_cost = 0

    for line in quote.lines:
        product = product_map.get(line.product_code)
        if product is None:
            return None
        total_amount += calculate_line_amount(line)
        total_cost += product.standard_cost * line.quantity

    if total_amount == 0:
        return None
    return round((total_amount - total_cost) / total_amount, 4)


def has_invalid_discount(line: QuoteLine) -> bool:
    # 現行実装では、50%を超える明らかな入力ミスだけを止めている。
    # 業務承認が必要な値引き率しきい値は未実装。
    return line.discount_rate < 0 or line.discount_rate > 0.5
