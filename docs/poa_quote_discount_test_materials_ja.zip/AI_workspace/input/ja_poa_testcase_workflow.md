# Testcase: 日本語 POA Workflow Routing

## 目的

Product Owner Assistant が、日本語のRFP、主管部回答、合成ソースコード、作業ログを読み、
ユーザー発話から適切な workflow を1つ選択できるか検証する。

この fixture のソースコードは、実在リポジトリから抽出したものではなく、workflow 検証用に設計した合成入力である。

## Seed Files

- `AI_workspace/input/ja_quote_discount_rfp.md`
- `AI_workspace/input/ja_stakeholder_reply_round1.md`
- `AI_workspace/input/source_quote_portal/`
- `AI_workspace/input/ja_current_state_reset_NO_PROJECT.json`
- `AI_workspace/input/ja_resume_seed_state.json`
- `AI_workspace/input/ja_seed_work_log_before_resume.md`
- `AI_workspace/input/ja_expected_answers.md`

## 共通制約

- 出力は日本語で書く。
- workflow は1回につき1つだけ選ぶ。
- 新規RFP入力時は、現在状態と最新作業ログが存在する場合は先に読む。
- 主管部回答を受けた場合は、既存成果物を最初から作り直さず差分更新する。
- 実現性確認では `AI_workspace/input/source_quote_portal/` の合成ソースコードを根拠に含める。
- resume では `current_state` と最新 work log を読み、前回の続きとして扱う。

## TC1: 新規RFP入力

### ユーザー入力

`AI_workspace/input/ja_quote_discount_rfp.md` は新しいRFPです。内容を整理して業務要件の初稿を作ってください。

### Agent が判断すべき分類

新規RFP入力

### 実行すべき workflow

business-requirements-initial

### 期待される回答の要点

`AI_workspace/input/ja_expected_answers.md` の `TC1` を参照。

## TC2: 会議・フィードバック反映

### ユーザー入力

主管部から `AI_workspace/input/ja_stakeholder_reply_round1.md` の回答が来ました。AとBを反映して、業務要件を更新してください。

### Agent が判断すべき分類

会議/フィードバック反映

### 実行すべき workflow

business-requirements-update

### 期待される回答の要点

`AI_workspace/input/ja_expected_answers.md` の `TC2` を参照。

## TC3: 開発要件化

### ユーザー入力

要件はだいたい固まったので、開発タスクに落としてください。未確定事項はリスクとして残してください。

### Agent が判断すべき分類

開発要件化

### 実行すべき workflow

dev-requirements-initial

### 期待される回答の要点

`AI_workspace/input/ja_expected_answers.md` の `TC3` を参照。

## TC4: 実現性確認

### ユーザー入力

合成ソースを見て、値引き承認ワークフローと粗利率のロール別表示は大体実装できますか？

### Agent が判断すべき分類

実現性確認

### 実行すべき workflow

feasibility-check

### 期待される回答の要点

`AI_workspace/input/ja_expected_answers.md` の `TC4` を参照。

## TC5: 確認質問生成

### ユーザー入力

今、主管部に何を確認すべきですか？

### Agent が判断すべき分類

確認問題生成

### 実行すべき workflow

clarification-question-generation

### 期待される回答の要点

`AI_workspace/input/ja_expected_answers.md` の `TC5` を参照。

## TC6: 前回作業の再開

### 事前準備

- `AI_workspace/input/ja_resume_seed_state.json` を `AI_workspace/state/current_state.json` として配置する。
- `AI_workspace/input/ja_seed_work_log_before_resume.md` を最新 work log として扱う。

### ユーザー入力

続きからお願いします。

### Agent が判断すべき分類

resume

### 実行すべき workflow

read work_logs and continue

### 期待される回答の要点

`AI_workspace/input/ja_expected_answers.md` の `TC6` を参照。
